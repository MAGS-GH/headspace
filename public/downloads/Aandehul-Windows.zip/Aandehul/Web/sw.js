const BUILD_VERSION = "4374c46f425355b1a5a3";
const PRECACHE = [
  "./assets/dm-sans-latin-wght-normal-Xz1IZZA0.woff2",
  "./assets/index-D9RBS7bS.js",
  "./assets/index-Dl5KN1PR.css",
  "./assets/lora-latin-wght-normal-BiLcIKcI.woff2",
  "./icons/apple-touch-icon.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/maskable-512.png",
  "./images/body.webp",
  "./images/breath.webp",
  "./images/evening.webp",
  "./images/hills.webp",
  "./images/meadow.webp",
  "./images/pebble-parts/body.png",
  "./images/pebble-parts/eyes-happy.png",
  "./images/pebble-parts/eyes-open.png",
  "./images/pebble-parts/eyes-rest.png",
  "./images/pebble-parts/mouth-round.png",
  "./images/pebble-parts/mouth-smile.png",
  "./images/pebble-parts/mouth-talk.png",
  "./images/pebble-parts/sprout.png",
  "./images/pebble.png",
  "./images/pond.webp",
  "./images/reeds.webp",
  "./index.html",
  "./licenses/dm-sans.txt",
  "./licenses/lora.txt",
  "./licenses/lucide.txt",
  "./manifest.webmanifest",
  "./register-sw.js",
  "./soundscapes/music-afternoon-lullaby.mp3",
  "./soundscapes/music-gymnopedie.mp3",
  "./soundscapes/music-vaporware.mp3",
  "./soundscapes/nature-birds.mp3",
  "./soundscapes/nature-stream.mp3",
  "./voice/complete.mp3",
  "./voice/et-roligt-oejeblik-0.mp3",
  "./voice/et-roligt-oejeblik-1.mp3",
  "./voice/et-roligt-oejeblik-2.mp3",
  "./voice/et-roligt-oejeblik-3.mp3",
  "./voice/exhale.mp3",
  "./voice/giv-slip-paa-dagen-0.mp3",
  "./voice/giv-slip-paa-dagen-1.mp3",
  "./voice/giv-slip-paa-dagen-2.mp3",
  "./voice/giv-slip-paa-dagen-3.mp3",
  "./voice/giv-slip-paa-dagen-4.mp3",
  "./voice/greeting.mp3",
  "./voice/inhale.mp3",
  "./voice/kropsscanning-0.mp3",
  "./voice/kropsscanning-1.mp3",
  "./voice/kropsscanning-2.mp3",
  "./voice/kropsscanning-3.mp3",
  "./voice/kropsscanning-4.mp3",
  "./voice/kropsscanning-5.mp3",
  "./voice/lette-skuldre-0.mp3",
  "./voice/lette-skuldre-1.mp3",
  "./voice/lette-skuldre-2.mp3",
  "./voice/lette-skuldre-3.mp3",
  "./voice/lette-skuldre-4.mp3",
  "./voice/little-stone.mp3",
  "./voice/mouth.json",
  "./voice/pause.mp3",
  "./voice/SOURCE.txt",
  "./voice/welcome.mp3"
];
/* BUILD_VERSION and PRECACHE are injected by the production build. */
const prefix = "aandehul:" + self.registration.scope + ":";
const cacheName = prefix + BUILD_VERSION;
const shell = new URL("./index.html", self.registration.scope).href;
const downloads = new URL("./downloads/", self.registration.scope).href;
const assets = new Set(PRECACHE.map(path => new URL(path, self.registration.scope).href));

self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(cacheName);
    await cache.addAll([...assets].map(url => new Request(url, { cache: "reload" })));
  })());
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});

// Media elements can request only a slice of an MP3, even for its first playback.
async function audioRange(response, rangeHeader) {
  const range = /^bytes=(\d*)-(\d*)$/.exec(rangeHeader);
  if (!range || (!range[1] && !range[2])) return response;
  const audio = await response.blob();
  const start = range[1] ? Number(range[1]) : Math.max(0, audio.size - Number(range[2]));
  const end = range[1] && range[2] ? Math.min(Number(range[2]), audio.size - 1) : audio.size - 1;
  if (start > end || start >= audio.size) {
    return new Response(null, { status: 416, headers: { "Content-Range": "bytes */" + audio.size } });
  }
  return new Response(audio.slice(start, end + 1), {
    status: 206,
    headers: {
      "Content-Type": "audio/mpeg",
      "Accept-Ranges": "bytes",
      "Content-Range": "bytes " + start + "-" + end + "/" + audio.size,
      "Content-Length": String(end - start + 1)
    }
  });
}

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  url.search = "";
  if (!url.href.startsWith(self.registration.scope) || url.href.startsWith(downloads)) return;
  const isAppNavigation = request.mode === "navigate" && !/\.[a-z0-9]+$/i.test(url.pathname);
  const cacheKey = isAppNavigation ? shell : url.href;
  if (!assets.has(cacheKey)) return;
  event.respondWith((async () => {
    const cache = await caches.open(cacheName);
    const cached = await cache.match(cacheKey);
    if (!cached) return fetch(request);
    const range = request.headers.get("Range");
    if (range && url.pathname.endsWith(".mp3")) return audioRange(cached, range);
    return cached;
  })());
});
