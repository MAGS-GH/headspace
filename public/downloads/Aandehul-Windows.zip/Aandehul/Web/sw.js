const BUILD_VERSION = "8ab6265432d00696c1e7";
const PRECACHE = [
  "./assets/dm-sans-latin-wght-normal-Xz1IZZA0.woff2",
  "./assets/index-BcXgS_p7.js",
  "./assets/index-C7DQoUe9.css",
  "./assets/lora-latin-wght-normal-BiLcIKcI.woff2",
  "./icons/apple-touch-icon.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/maskable-512.png",
  "./images/body.webp",
  "./images/breath.webp",
  "./images/evening.webp",
  "./images/hills.webp",
  "./images/meadow.webp",
  "./images/pebble.png",
  "./images/pond.webp",
  "./images/reeds.webp",
  "./index.html",
  "./licenses/dm-sans.txt",
  "./licenses/lora.txt",
  "./licenses/lucide.txt",
  "./manifest.webmanifest",
  "./register-sw.js"
];
/* BUILD_VERSION and PRECACHE are injected by the production build. */
const prefix = "aandehul:" + self.registration.scope + ":";
const cacheName = prefix + BUILD_VERSION;
const shell = new URL("./index.html", self.registration.scope).href;
const downloads = new URL("./downloads/", self.registration.scope).href;
const assets = new Set(PRECACHE.map(path => new URL(path, self.registration.scope).href));

self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(cacheName);
    await cache.addAll([...assets].map(url => new Request(url, { cache: "reload" })));
  })());
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  url.search = "";
  if (!url.href.startsWith(self.registration.scope) || url.href.startsWith(downloads)) return;
  const isAppNavigation = request.mode === "navigate" && !/\.[a-z0-9]+$/i.test(url.pathname);
  const cacheKey = isAppNavigation ? shell : url.href;
  if (!assets.has(cacheKey)) return;
  event.respondWith((async () => {
    const cache = await caches.open(cacheName);
    return await cache.match(cacheKey) ?? fetch(request);
  })());
});
