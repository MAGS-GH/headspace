(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[{id:`rolig-vejrtraekning`,title:`Rolig vejrtrækning`,description:`Følg en blid rytme, ét åndedrag ad gangen.`,category:`Vejrtrækning`,minutes:3,durations:[1,3,5],breath:{inhale:4,exhale:4},steps:[{title:`Træk vejret ind`,instruction:`Lad luften komme stille ind i dit eget tempo.`},{title:`Pust langsomt ud`,instruction:`Lad skuldrene hvile, mens luften slipper ud.`}]},{id:`kropsscanning`,title:`Kropsscanning`,description:`Lad opmærksomheden gå på besøg i kroppen.`,category:`Afspænding`,minutes:5,durations:[3,5,10],steps:[{title:`Find dig til rette`,instruction:`Mærk fladen under dig. Lad hænderne hvile, hvor de har lyst.`},{title:`Mærk dine fødder`,instruction:`Læg mærke til tæerne, hælene og kontakten med gulvet.`},{title:`Giv benene plads`,instruction:`Flyt opmærksomheden langsomt fra anklerne op mod hofterne.`},{title:`Hvil i midten`,instruction:`Læg mærke til den lille bevægelse i maven, når du trækker vejret.`},{title:`Mærk dine skuldre`,instruction:`Følg armene helt ud til fingerspidserne. Måske føles én hånd varmere.`},{title:`Vend stille tilbage`,instruction:`Mærk kroppen som en helhed. Bevæg forsigtigt fingre og tæer.`,pose:`awake`}]},{id:`giv-slip-paa-dagen`,title:`Giv slip på dagen`,description:`En stille meditation til dagens sidste stund.`,category:`Meditation`,minutes:7,durations:[3,7,10],steps:[{title:`Land her`,instruction:`Lad blikket hvile på et roligt punkt, eller luk øjnene et øjeblik.`},{title:`Lad dagen passere`,instruction:`Måske dukker et øjeblik fra dagen op. Lad det ligge et øjeblik.`,pose:`rest`},{title:`Mærk et åndedrag`,instruction:`Følg luften ind og ud. Du må gerne vende tilbage til åndedrættet mange gange.`,pose:`rest`},{title:`Find én lille ting`,instruction:`Tænk på en lille ting fra i dag, som var rar. Bliv lidt ved den.`,pose:`happy`},{title:`Tag roen med`,instruction:`Mærk rummet omkring dig, og kom langsomt tilbage i dit eget tempo.`,pose:`awake`}]},{id:`et-roligt-oejeblik`,title:`Et roligt øjeblik`,description:`Find et lille holdepunkt i lydene omkring dig.`,category:`Meditation`,minutes:3,durations:[1,3,5],steps:[{title:`Sæt dig godt`,instruction:`Find en behagelig stilling. Mærk dine fødder mod underlaget.`},{title:`Lyt til rummet`,instruction:`Læg mærke til en lyd i nærheden. Lad den komme og gå.`},{title:`Lyt lidt længere væk`,instruction:`Måske kan du høre noget udenfor. Vend roligt tilbage, når tankerne vandrer.`},{title:`Vend tilbage`,instruction:`Lad blikket glide rundt i rummet. Giv dig tid til at komme videre.`,pose:`awake`}]},{id:`blid-udanding`,title:`Blid udånding`,description:`Giv udåndingen lidt ekstra tid og plads.`,category:`Vejrtrækning`,minutes:2,durations:[1,2,5],breath:{inhale:3,exhale:5},steps:[{title:`Træk vejret ind`,instruction:`Tag en let indånding i en rytme, som passer dig.`},{title:`Lad luften slippe ud`,instruction:`Giv udåndingen lidt længere tid, så længe det føles rart.`}]},{id:`lette-skuldre`,title:`Lette skuldre`,description:`En lille afspænding ved skrivebordet.`,category:`Afspænding`,minutes:3,durations:[1,3,5],steps:[{title:`Find en rar stilling`,instruction:`Lad fødderne hvile mod gulvet og armene ligge løst langs siden.`},{title:`Mærk dine skuldre`,instruction:`Læg mærke til, hvordan skuldrene føles lige nu.`},{title:`Løft ganske let`,instruction:`Hvis det føles rart, så løft langsomt skuldrene en smule og lad dem synke igen.`},{title:`Lad armene hvile`,instruction:`Mærk vægten i hænderne. Giv kæben lidt plads.`},{title:`Find tilbage`,instruction:`Bevæg forsigtigt fingrene og lad blikket vende tilbage til rummet.`,pose:`awake`}]}],t=`aandehul.session.v1.`,n=`aandehul.favorite.v1.`,r=new Map;function i(e){if(r.has(e))return r.get(e);try{return localStorage.getItem(e)}catch{return null}}function a(e,t){let n=!0;try{localStorage.setItem(e,t),r.delete(e)}catch{r.set(e,t),n=!1}return window.dispatchEvent(new Event(`aandehul:change`)),n}typeof window<`u`&&window.addEventListener(`storage`,e=>{(e.key===null||e.key.startsWith(t)||e.key.startsWith(n))&&(e.key===null?r.clear():r.delete(e.key),window.dispatchEvent(new Event(`aandehul:change`)))});function o(e){return i(n+e)===`true`}function s(t){if(!e.some(e=>e.id===t))return!1;let r=!o(t);return a(n+t,String(r)),r}function c(t){if(!t||typeof t!=`object`)return!1;let n=t;return typeof n.exerciseId==`string`&&e.some(e=>e.id===n.exerciseId)&&typeof n.seconds==`number`&&Number.isFinite(n.seconds)&&n.seconds>0&&typeof n.startedAt==`string`&&Number.isFinite(Date.parse(n.startedAt))&&typeof n.finishedAt==`string`&&Number.isFinite(Date.parse(n.finishedAt))&&typeof n.completed==`boolean`}function l(){let e=new Set(r.keys());try{for(let n=0;n<localStorage.length;n++){let r=localStorage.key(n);r?.startsWith(t)&&e.add(r)}}catch{}let n=[];for(let r of e)if(r.startsWith(t))try{let e=JSON.parse(i(r)??`null`);c(e)&&n.push(e)}catch{}return n.sort((e,t)=>Date.parse(t.finishedAt)-Date.parse(e.finishedAt))}function u(e){if(!c(e))return!1;let n=t+e.exerciseId+`.`+e.startedAt,o=JSON.stringify(e);return!r.has(n)&&i(n)===o||a(n,o)}if(typeof window<`u`){let e=window.chrome?.webview;e&&(e.addEventListener(`message`,t=>{let n=t.data;n?.type===`pebble-session`&&c(n.record)&&u(n.record)&&e.postMessage(`pebble-saved:`+n.record.startedAt)}),e.postMessage(`pebble-ready`))}function ee(e,t,n){if(e.breath){let{inhale:r,exhale:i}=e.breath,a=t%(r+i),o=a<r,s=o?r:i,c=o?a:a-r,l=c/s,u=(1-Math.cos(Math.PI*l))/2;return{...e.steps[+!o],index:+!o,expansion:o?u:1-u,phase:{direction:o?`inhale`:`exhale`,seconds:s,remaining:Math.ceil(Math.min(s-c,n-t)),fraction:l}}}let r=Math.min(e.steps.length-1,Math.floor(t/n*e.steps.length));return{...e.steps[r],index:r,expansion:(1-Math.cos(t/5))/2}}var te=Object.assign({"./icons/arrow-right.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-arrow-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
  <path d="m12 5 7 7-7 7" />
</svg>
`,"./icons/audio-lines.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-audio-lines"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 10v3" />
  <path d="M6 6v11" />
  <path d="M10 3v18" />
  <path d="M14 8v7" />
  <path d="M18 5v13" />
  <path d="M22 10v3" />
</svg>
`,"./icons/book-open.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-book-open"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 5v16" />
  <path d="M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z" />
</svg>
`,"./icons/check.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 6 9 17l-5-5" />
</svg>
`,"./icons/clock.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-clock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 6v6l4 2" />
</svg>
`,"./icons/cloud-moon.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-cloud-moon"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M13 16a3 3 0 0 1 0 6H7a5 5 0 1 1 4.9-6z" />
  <path d="M18.376 14.512a6 6 0 0 0 3.461-4.127c.148-.625-.659-.97-1.248-.714a4 4 0 0 1-5.259-5.26c.255-.589-.09-1.395-.716-1.248a6 6 0 0 0-4.594 5.36" />
</svg>
`,"./icons/cloud-rain.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-cloud-rain"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242" />
  <path d="M16 14v6" />
  <path d="M8 14v6" />
  <path d="M12 16v6" />
</svg>
`,"./icons/download.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-download"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 15V3" />
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
  <path d="m7 10 5 5 5-5" />
</svg>
`,"./icons/flower-2.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-flower-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 5a3 3 0 1 1 3 3m-3-3a3 3 0 1 0-3 3m3-3v1M9 8a3 3 0 1 0 3 3M9 8h1m5 0a3 3 0 1 1-3 3m3-3h-1m-2 3v-1" />
  <circle cx="12" cy="8" r="2" />
  <path d="M12 10v12" />
  <path d="M12 22c4.2 0 7-1.667 7-5-4.2 0-7 1.667-7 5Z" />
  <path d="M12 22c-4.2 0-7-1.667-7-5 4.2 0 7 1.667 7 5Z" />
</svg>
`,"./icons/frown.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-frown"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 10V9" />
  <path d="M9 10V9" />
  <path d="M9 16a5 5 0 016 0" />
  <circle cx="12" cy="12" r="10" />
</svg>
`,"./icons/headphones.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-headphones"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3" />
</svg>
`,"./icons/heart.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-heart"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5" />
</svg>
`,"./icons/history.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-history"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
  <path d="M3 3v5h5" />
  <path d="M12 7v5l4 2" />
</svg>
`,"./icons/house.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-house"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8" />
  <path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
</svg>
`,"./icons/leaf.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-leaf"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 20a10 10 0 0010-10 25.9 25.9 0 00-1.04-7.281 1 1 0 00-1.755-.325C15.833 5.5 13 5.5 9.8 6.1A7 7 0 0011 20" />
  <path d="M2 21a5 5 0 012.911-4.544C7.613 15.212 8.351 15.24 11 13" />
</svg>
`,"./icons/menu.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-menu"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 5h16" />
  <path d="M4 12h16" />
  <path d="M4 19h16" />
</svg>
`,"./icons/monitor.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-monitor"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="14" x="2" y="3" rx="2" />
  <line x1="8" x2="16" y1="21" y2="21" />
  <line x1="12" x2="12" y1="17" y2="21" />
</svg>
`,"./icons/moon-star.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-moon-star"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 5h4" />
  <path d="M20 3v4" />
  <path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401" />
</svg>
`,"./icons/notebook-pen.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-notebook-pen"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" />
  <path d="M2 6h4" />
  <path d="M2 10h4" />
  <path d="M2 14h4" />
  <path d="M2 18h4" />
  <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" />
</svg>
`,"./icons/pause.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-pause"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect x="14" y="3" width="5" height="18" rx="1" />
  <rect x="5" y="3" width="5" height="18" rx="1" />
</svg>
`,"./icons/play.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-play"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z" />
</svg>
`,"./icons/settings.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-settings"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915" />
  <circle cx="12" cy="12" r="3" />
</svg>
`,"./icons/smile.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-smile"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 10V9" />
  <path d="M16.472 15a6 6 0 01-8.943 0" />
  <path d="M9 10V9" />
  <circle cx="12" cy="12" r="10" />
</svg>
`,"./icons/sun.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-sun"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="4" />
  <path d="M12 2v2" />
  <path d="M12 20v2" />
  <path d="m4.93 4.93 1.41 1.41" />
  <path d="m17.66 17.66 1.41 1.41" />
  <path d="M2 12h2" />
  <path d="M20 12h2" />
  <path d="m6.34 17.66-1.41 1.41" />
  <path d="m19.07 4.93-1.41 1.41" />
</svg>
`,"./icons/sunrise.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-sunrise"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 2v8" />
  <path d="m4.93 10.93 1.41 1.41" />
  <path d="M2 18h2" />
  <path d="M20 18h2" />
  <path d="m19.07 10.93-1.41 1.41" />
  <path d="M22 22H2" />
  <path d="m8 6 4-4 4 4" />
  <path d="M16 18a4 4 0 0 0-8 0" />
</svg>
`,"./icons/volume-2.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-volume-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z" />
  <path d="M16 9a5 5 0 0 1 0 6" />
  <path d="M19.364 18.364a9 9 0 0 0 0-12.728" />
</svg>
`,"./icons/volume-x.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-volume-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 4.702a.7.7 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.7.7 0 0 0 11 19.298z" />
  <path d="m16.5 14.5 5-5" />
  <path d="m16.5 9.5 5 5" />
</svg>
`,"./icons/waves.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-waves"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 12q2.5 2 5 0t5 0 5 0 5 0" />
  <path d="M2 19q2.5 2 5 0t5 0 5 0 5 0" />
  <path d="M2 5q2.5 2 5 0t5 0 5 0 5 0" />
</svg>
`,"./icons/wind.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-wind"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.8 19.6A2 2 0 1 0 14 16H2" />
  <path d="M17.5 8a2.5 2.5 0 1 1 2 4H2" />
  <path d="M9.8 4.4A2 2 0 1 1 11 8H2" />
</svg>
`,"./icons/x.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 6 6 18" />
  <path d="m6 6 12 12" />
</svg>
`});function d(e){let t=te[`./icons/`+e+`.svg`];return t?t.replace(`<svg`,`<svg aria-hidden="true" focusable="false"`):``}var ne=[{id:`music-afternoon-lullaby`,name:`Afternoon Lullaby`,title:`Afternoon Lullaby`,artist:`Diminixed`,description:`En stille klavermelodi fra spillet VoxeLibre.`,src:`/soundscapes/music-afternoon-lullaby.mp3`,duration:67,sourceUrl:`https://github.com/VoxeLibre/VoxeLibre/blob/4492ce6ff8d856daa4567abe2ea689f4e7a39842/CREDITS.md#music`,license:`CC BY-SA 4.0`,licenseUrl:`https://creativecommons.org/licenses/by-sa/4.0/`,changes:`Konverteret fra Ogg Vorbis til MP3 med lydniveauet sænket 0,4 dB. Denne udgave er også under CC BY-SA 4.0.`},{id:`music-gymnopedie`,name:`Gymnopédie nr. 1`,title:`Gymnopedie No. 1`,artist:`Erik Satie, spillet af Kevin MacLeod`,description:`Soloklaver med luft mellem de bløde akkorder.`,src:`/soundscapes/music-gymnopedie.mp3`,duration:187,sourceUrl:`https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100787`,license:`CC BY 4.0`,licenseUrl:`https://creativecommons.org/licenses/by/4.0/`,changes:`Lydniveauet er sænket 1 dB. Kodet som MP3 ved 128 kbit/s.`},{id:`music-vaporware`,name:`Vaporware`,title:`Vaporware`,artist:`The Cynic Project`,description:`Lyst klaver over varme, svævende synthtoner.`,src:`/soundscapes/music-vaporware.mp3`,duration:165,sourceUrl:`https://opengameart.org/content/calm-piano-1-vaporware`,license:`CC0 1.0`,licenseUrl:`https://creativecommons.org/publicdomain/zero/1.0/`,changes:`Lydniveauet er sænket 2,6 dB. Kodet som MP3 ved 128 kbit/s.`}],f=`https://opengameart.org/content/park-ambiences`,p=`https://creativecommons.org/publicdomain/zero/1.0/`,re=[{id:`nature-stream`,name:`Vandløbet`,artist:`Thimras`,title:`Park ambiences – park_ambience_river.wav`,description:`Vand risler over et lavt fald.`,src:`/soundscapes/nature-stream.mp3`,duration:90,sourceUrl:f,license:`CC0 1.0`,licenseUrl:p,changes:`Udsnit fra 0:42 til 2:18. Seks sekunders overlap, let filtrering og justeret lydstyrke. Stereo-MP3.`},{id:`nature-birds`,name:`Fugle før regnen`,artist:`Thimras`,title:`Park ambiences – park_ambience_birds.wav`,description:`Fuglekald mellem træerne før regnen.`,src:`/soundscapes/nature-birds.mp3`,duration:90,sourceUrl:f,license:`CC0 1.0`,licenseUrl:p,changes:`Udsnit fra 0:21 til 1:57. Seks sekunders overlap, let filtrering og justeret lydstyrke. Stereo-MP3.`}],m=[...ne.map(e=>h(e,`music`,`headphones`)),...re.map(e=>h(e,`nature`,e.id===`nature-stream`?`waves`:`leaf`)),{id:`rain`,name:`Stille regn`,icon:`cloud-rain`,group:`nature`,noise:`rain`},{id:`sea`,name:`Havbrus`,icon:`waves`,group:`nature`,noise:`sea`},{id:`wind`,name:`Skovvind`,icon:`wind`,group:`nature`,noise:`wind`}];function h(e,t,n){return{id:e.id,name:e.name,icon:n,group:t,recording:e}}var g=null,_=.35,v=!1,y=!1;try{let e=localStorage.getItem(`aandehul.ambient.volume`);e!==null&&Number.isFinite(Number(e))&&(_=Math.max(0,Math.min(1,Number(e))))}catch{}var b=()=>({selected:g?.sound.id??`off`,level:_});function ie(e){if(!g)return;let t=g.sound.noise?.48:1;g.gain.gain.setTargetAtTime(_*t*(v||y?.45:1),g.audio.currentTime,e)}function ae(e){y=e,ie(e?.07:.28)}function oe(e){_=Math.max(0,Math.min(1,e)),ie(.075);try{localStorage.setItem(`aandehul.ambient.volume`,String(_))}catch{}}window.addEventListener(`aandehul:pebble-speaking`,e=>{v=e.detail,ie(v?.07:.28)});function se(e,t,n){let r=t.createBuffer(1,t.sampleRate*5,t.sampleRate),i=r.getChannelData(0),a=0;for(let t=0;t<i.length;t++){let n=Math.random()*2-1;a=(a+n*.035)/1.035,i[t]=e===`rain`?n*.55+a:a*4}let o=t.createBufferSource();o.buffer=r,o.loop=!0;let s=t.createBiquadFilter();s.type=`lowpass`,s.Q.value=.45,s.frequency.value=e===`rain`?2350:e===`sea`?1150:720;let c=t.createGain();c.gain.value=e===`rain`?.75:.6;let l=t.createOscillator(),u=t.createGain();u.gain.value=e===`rain`?.07:e===`sea`?.38:.21,l.frequency.value=e===`sea`?.093:.062,l.connect(u).connect(c.gain),o.connect(s).connect(c).connect(n),l.start(),o.start()}function x(e){let{audio:t,gain:n,media:r}=e;n.gain.setTargetAtTime(0,t.currentTime,.04),r&&(r.onerror=null),window.setTimeout(()=>{r&&(r.pause(),r.removeAttribute(`src`),r.load()),t.close().catch(()=>{})},200)}function S(e=!1){window.dispatchEvent(new CustomEvent(`aandehul:ambient-change`,{detail:{error:e}}))}async function C(e){let t=m.find(t=>t.id===e);if(e!==`off`&&!t)return;if(g){let e=g;g=null,x(e)}if(!t){S();return}let n=null;try{let e=new AudioContext,r=e.createGain();r.gain.value=0,r.connect(e.destination),n={sound:t,audio:e,gain:r},g=n,S();let i=e.resume();if(t.recording){let a=new Audio(t.recording.src);a.loop=!0,n.media=a,e.createMediaElementSource(a).connect(r),a.onerror=()=>{g===n&&n&&(g=null,x(n),S(!0))},await Promise.all([i,a.play()])}else t.noise&&(await i,g===n&&se(t.noise,e,r));g===n&&ie(.2)}catch{if(g!==n)return;g=null,n&&x(n),S(!0)}}window.addEventListener(`pagehide`,()=>{g&&C(`off`)});var w={"music-afternoon-lullaby":`meadow`,"music-gymnopedie":`body`,"music-vaporware":`evening`,"nature-stream":`pond`,"nature-birds":`breath`},T=document.createElement(`dialog`);T.className=`sound-library`,T.setAttribute(`aria-labelledby`,`sound-library-title`);var E=`music`;function D(e){return Math.floor(e/60)+`:`+String(e%60).padStart(2,`0`)}function O(e){let t=e.recording,n=t?`<img class="track-cover" src="/images/${w[e.id]}.webp" alt="">`:`<span class="noise-symbol">${d(e.icon)}</span>`;return`<button type="button" class="track-choice" data-audio="${e.id}" aria-pressed="false">
    ${n}<span class="track-info"><strong>${e.name}</strong>${t?`<small>${t.description}</small>`:``}</span>
    ${t?`<span class="track-time">${D(t.duration)}</span>`:``}<span class="track-control">${d(`play`)}</span>
  </button>`}function k(e=!1){if(!T.open)return;let{selected:t}=b(),n=m.find(e=>e.id===t);for(let e of T.querySelectorAll(`.track-choice`)){let n=e.dataset.audio===t;e.setAttribute(`aria-pressed`,String(n)),e.setAttribute(`aria-label`,(n?`Stop `:`Afspil `)+e.querySelector(`strong`).textContent),e.querySelector(`.track-control`).innerHTML=d(n?`audio-lines`:`play`)}T.querySelector(`[data-audio="off"]`).disabled=!n,T.querySelector(`[data-now-playing]`).textContent=e?`Lyden kunne ikke starte. Vælg et spor for at prøve igen.`:n?n.name+` spiller i løkke`:`Stilhed`}function A(){for(let e of T.querySelectorAll(`[data-group]`))e.setAttribute(`aria-pressed`,String(e.dataset.group===E));let e=m.filter(e=>e.group===E),t=e.filter(e=>e.recording),n=e.filter(e=>e.noise);T.querySelector(`.track-list`).innerHTML=t.map(O).join(``)+(n.length?`<h3>Bløde lydflader</h3><div class="noise-choices">${n.map(O).join(``)}</div>`:``),T.querySelector(`.original-music`).hidden=E!==`music`,k()}function ce(e){if(T.open)return;let{selected:t,level:n}=b();E=m.find(e=>e.id===t)?.group??`music`;let r=m.flatMap(({recording:e})=>e?[e]:[]).map(e=>`<li><strong>${e.title}</strong><span>${e.artist}</span><small>${e.changes}</small><div><a href="${e.sourceUrl}" target="_blank" rel="noopener noreferrer">Originalkilde</a><a href="${e.licenseUrl}" target="_blank" rel="noopener noreferrer">${e.license}</a></div></li>`).join(``);T.innerHTML=`
    <div class="sound-heading"><h2 id="sound-library-title">Lydmiljø</h2><button type="button" data-close class="circle-button" aria-label="Luk lydmiljø">${d(`x`)}</button></div>
    <div class="sound-tabs" role="group" aria-label="Vælg lydtype">
      <button type="button" data-group="music">${d(`headphones`)}Musik</button>
      <button type="button" data-group="nature">${d(`leaf`)}Naturlyde</button>
    </div>
    <div class="track-list"></div>
    <a class="original-music" href="https://c418.bandcamp.com/track/sweden" target="_blank" rel="noopener noreferrer">Hør <i>Sweden</i> fra Minecraft på Bandcamp ${d(`arrow-right`)}</a>
    <div class="sound-mix">
      <div class="playing-line"><span role="status" aria-live="polite" data-now-playing></span><button type="button" data-audio="off">Stop lyd</button></div>
      <label class="volume-line" for="ambient-volume">${d(`volume-2`)}Lydstyrke <output for="ambient-volume">${Math.round(n*100)} %</output></label>
      <input id="ambient-volume" type="range" min="0" max="100" value="${Math.round(n*100)}">
    </div>
    <details class="sound-credits"><summary>Kunstnere og licenser</summary><ul>${r}</ul></details>`,document.body.appendChild(T),e&&T.addEventListener(`close`,e,{once:!0}),T.showModal(),A()}T.addEventListener(`click`,e=>{let t=e.target.closest(`button,a`);if(t?.hasAttribute(`data-close`))T.close();else if(t?.dataset.group)E=t.dataset.group,A();else if(t?.dataset.audio){let e=t.dataset.audio;C(e===b().selected?`off`:e)}else if(t?.classList.contains(`original-music`)&&C(`off`),e.target===T){let t=T.getBoundingClientRect();(e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom)&&T.close()}}),T.addEventListener(`input`,e=>{let t=e.target;t.id===`ambient-volume`&&(oe(t.valueAsNumber/100),T.querySelector(`output`).value=t.value+` %`)}),window.addEventListener(`aandehul:ambient-change`,e=>k(e.detail?.error));var j=[`body`,`sprout`,`eyes-rest`,`eyes-open`,`eyes-happy`,`mouth-smile`,`mouth-round`,`mouth-talk`];function le(e=`rest`){return`<span class="pebble-figure" data-pose="${e}" aria-hidden="true">${j.map(e=>`<img class="pebble-part part-${e}" src="./images/pebble-parts/${e}.png" alt="" draggable="false">`).join(``)}</span>`}var M=new Map([[`kropsscanning`,6],[`giv-slip-paa-dagen`,5],[`et-roligt-oejeblik`,4],[`lette-skuldre`,5]]),N,P=0,F=``,I=!1,L,R,ue,de=-1;function fe(e){de!==e&&(de=e,document.documentElement.style.setProperty(`--pebble-jaw`,String(e)))}function pe(){if(!N||!I)return;let e=R?.clips[F];if(e&&R){let t=Math.floor(N.currentTime*1e3/R.stepMs),n=Number(e[t]??0);fe(Number.isFinite(n)?n/9:0)}else fe(.28+.14*Math.sin(N.currentTime*17))}function z(e){I!==e&&(I=e,e?(pe(),L=window.setInterval(pe,40)):(clearInterval(L),fe(0)),window.dispatchEvent(new CustomEvent(`aandehul:pebble-speaking`,{detail:e})))}function B(){let e=new Audio;e.volume=.84,e.addEventListener(`playing`,()=>z(!e.paused));for(let t of[`pause`,`waiting`,`abort`])e.addEventListener(t,()=>z(!1));let t=()=>{if(!F)return;let e=F;F=``,z(!1),window.dispatchEvent(new CustomEvent(`aandehul:pebble-voice-ended`,{detail:e}))};return e.addEventListener(`ended`,()=>{e.ended&&t()}),e.addEventListener(`error`,()=>{e.error&&t()}),window.addEventListener(`pagehide`,_e),e}async function V(){try{let e=await fetch(`/voice/mouth.json`);if(!e.ok)return;let t=await e.json();Number.isFinite(t?.stepMs)&&t.stepMs>0&&t.clips&&(R=t)}catch{}}async function me(e){let t=++P;N??=B(),N.pause(),z(!1),ue??=V(),F=e,N.src=`/voice/${e}.mp3`;try{return await N.play(),t===P}catch{return!1}}function he(e){return me(e)}function ge(e,t){return!Number.isInteger(t)||t<0?Promise.resolve(!1):e===`rolig-vejrtraekning`||e===`blid-udanding`?t>1?Promise.resolve(!1):he(t===0?`inhale`:`exhale`):t>=(M.get(e)??0)?Promise.resolve(!1):me(`${e}-${t}`)}function _e(){P++,F=``,N?.pause(),z(!1)}var ve=`aandehul.cue-sound.v1`,ye=`aandehul.cue-speech.v1`,be=new Map,xe=null;function Se(e){return Math.floor(e/60)+`:`+String(e%60).padStart(2,`0`)}function Ce(e,t=!1){let n=be.get(e);if(n!==void 0)return n;try{let n=localStorage.getItem(e);return n===null?t:n===`on`}catch{return t}}function we(e,t){try{localStorage.setItem(e,t?`on`:`off`),be.delete(e)}catch{be.set(e,t)}}function Te(e,t){if(e.state!==`running`)return;let n=e.currentTime;for(let[r,i,a]of[[1,.065,1.65],[2,.012,.9]]){let o=e.createOscillator(),s=e.createGain();o.type=`sine`,o.frequency.value=t*r,s.gain.setValueAtTime(1e-4,n),s.gain.exponentialRampToValueAtTime(i,n+.055),s.gain.exponentialRampToValueAtTime(1e-4,n+a),o.connect(s).connect(e.destination),o.start(n),o.stop(n+a+.02),o.onended=()=>{o.disconnect(),s.disconnect()}}}function Ee(t,n){let r=e.find(e=>e.id===t);if(!r)return;if(xe){xe.focus();return}let i=n!==void 0&&r.durations.includes(n)?n:r.minutes,a=document.createElement(`dialog`);xe=a,a.className=`coach-player`,a.dataset.practice=r.breath?`breathing`:r.category===`Meditation`?`meditation`:`relaxation`,a.setAttribute(`aria-labelledby`,`coach-exercise-title`),a.innerHTML=`
    <div class="coach-sheet">
      <div class="coach-topline">
        <span class="coach-category"></span>
        <button type="button" class="coach-speech" aria-pressed="false"><span class="coach-speech-icon" aria-hidden="true"></span>Pebbles stemme<span class="coach-speech-switch" aria-hidden="true"></span></button>
        <button type="button" class="coach-close" aria-label="Afslut og luk øvelsen" title="Afslut og luk">${d(`x`)}</button>
      </div>
      <h2 id="coach-exercise-title"></h2>
      <div class="coach-orbit" aria-hidden="true">
        <div class="coach-orbit-rings"></div>
        <span class="coach-air coach-air-left">${d(`wind`)}</span>
        <span class="coach-air coach-air-right">${d(`wind`)}</span>
        <div class="coach-stone-scene">
          <div class="coach-ground-shadow"></div>
          <div class="coach-pebble">${le(`rest`)}</div>
        </div>
      </div>
      <div class="coach-pace" role="timer" aria-live="off">
        <span class="coach-pace-direction" aria-hidden="true">${d(r.breath?`arrow-right`:`leaf`)}</span>
        <span class="coach-beats" aria-hidden="true"></span>
        <span class="coach-pace-label"></span>
      </div>
      <div class="coach-cue" aria-live="polite" aria-atomic="true">
        <h3></h3><p></p>
      </div>
      <div class="coach-session-controls">
        <div class="coach-time">
          <span class="coach-timer" role="timer" aria-label="Tid brugt">0:00</span>
          <progress class="coach-progress" aria-label="Forløbet tid"></progress>
          <span class="coach-total"></span>
        </div>
        <div class="coach-actions">
          <label class="coach-duration">Varighed
            <select aria-label="Varighed i minutter"></select>
          </label>
          <button type="button" class="coach-playback"></button>
          <button type="button" class="coach-sound" aria-pressed="false"></button>
        </div>
        <button type="button" class="coach-ambient" aria-haspopup="dialog">${d(`headphones`)} Lydmiljø</button>
      </div>
      <p class="coach-voice-status" role="status" hidden></p>
      <button type="button" class="coach-done" hidden>Tilbage til mit åndehul</button>
    </div>`;let o=e=>a.querySelector(e),s=o(`.coach-orbit`),c=o(`.pebble-figure`),l=o(`.coach-pace`),te=o(`.coach-pace-label`),ne=o(`.coach-beats`),f=o(`.coach-cue h3`),p=o(`.coach-cue p`),re=o(`.coach-session-controls`),m=o(`.coach-playback`),h=o(`.coach-close`),g=o(`.coach-done`),_=o(`.coach-sound`),v=o(`.coach-speech`),y=o(`.coach-voice-status`),b=o(`select`),ie=o(`.coach-timer`),ae=o(`.coach-total`),oe=o(`.coach-progress`);o(`.coach-category`).textContent=r.category,o(`#coach-exercise-title`).textContent=r.title,b.replaceChildren(...r.durations.map(e=>new Option(e+` min`,String(e)))),b.value=String(i);let se=new Date().toISOString(),x=i*60,S=0,C=performance.now(),w=-1,T=-1,E=Ce(ve)&&typeof AudioContext<`u`,D,O=Ce(ye,!0),k=0,A=-1,j=!1,M=!1,N=0;function P(){let e=C===null?0:(performance.now()-C)/1e3;return Math.min(x,S+e)}async function F(e){if(E&&typeof AudioContext<`u`)try{D??=new AudioContext,D.state===`suspended`&&await D.resume(),!M&&E&&(C!==null||j)&&Te(D,e)}catch{M||(E=!1,I())}}function I(){_.innerHTML=d(E?`volume-2`:`volume-x`)+`<span>Klange</span>`,_.setAttribute(`aria-pressed`,String(E)),_.title=E?`Slå guideklange fra`:`Slå guideklange til`,_.setAttribute(`aria-label`,_.title),_.disabled=typeof AudioContext>`u`}function L(){k++,_e(),c.classList.remove(`is-talking`)}async function R(e=!1){if(!O||M||!e&&(C===null||w<0))return;let n=++k;y.hidden=!0,!await(e?he(`complete`):ge(t,w)).catch(()=>!1)&&n===k&&!M&&(y.textContent=`Stemmen kunne ikke starte. Du kan stadig følge teksten.`,y.hidden=!1)}function ue(e){let t=e.detail===!0;c.classList.toggle(`is-talking`,t&&O&&!M&&(C!==null||j))}function de(){o(`.coach-speech-icon`).innerHTML=d(O?`volume-2`:`volume-x`),v.setAttribute(`aria-pressed`,String(O)),v.title=O?`Slå Pebbles stemme fra`:`Slå Pebbles syntetiske danske stemme til`}function fe(){let e=C===null;m.innerHTML=d(e?`play`:`pause`)+(e?`Fortsæt`:`Pause`),m.setAttribute(`aria-label`,e?`Fortsæt øvelsen`:`Sæt øvelsen på pause`),a.classList.toggle(`coach-paused`,e)}function pe(e,n){let r=Math.floor(n);r>0&&u({exerciseId:t,startedAt:se,finishedAt:new Date().toISOString(),seconds:r,completed:e})}function z(){j||M||(j=!0,C=null,S=x,window.clearInterval(N),pe(!0,x),L(),F(523.25),a.classList.add(`coach-finished`),c.dataset.pose=`happy`,s.style.setProperty(`--coach-expansion`,`0.2`),s.style.setProperty(`--pebble-breath`,`0.2`),s.style.setProperty(`--coach-flow`,`0`),l.hidden=!0,f.textContent=`Din øvelse er færdig`,p.textContent=`Tak for stunden. Tag roen med dig.`,R(!0),re.hidden=!0,g.hidden=!1,h.setAttribute(`aria-label`,`Luk afspilleren`),h.title=`Luk`,g.focus({preventScroll:!0}))}function B(){if(M||j)return;let e=P();if(e>=x){z();return}let t=Math.floor(e);if(t!==T&&(T=t,ie.textContent=Se(t)),oe.value=e,C===null)return;let n=ee(r,e,x),i=n.expansion.toFixed(4);s.style.setProperty(`--coach-expansion`,i),s.style.setProperty(`--pebble-breath`,i);let{phase:o}=n;if(o&&s.style.setProperty(`--coach-flow`,Math.sin(Math.PI*o.fraction).toFixed(4)),n.index!==w&&(w=n.index,f.textContent=n.title,p.textContent=n.instruction,c.dataset.pose=o?.direction??n.pose??(r.category===`Meditation`?`listening`:`rest`),o?(a.dataset.phase=o.direction,l.setAttribute(`aria-label`,o.direction===`inhale`?`Tid tilbage af indåndingen`:`Tid tilbage af udåndingen`),ne.childElementCount!==o.seconds&&ne.replaceChildren(...Array.from({length:o.seconds},()=>document.createElement(`i`))),A=-1):te.textContent=`Trin `+(n.index+1)+` af `+r.steps.length,R(),F(n.index%2==0?392:329.63)),o&&o.remaining!==A){A=o.remaining,te.textContent=o.remaining+` sek.`;for(let[e,t]of Array.from(ne.children).entries())t.classList.toggle(`remaining`,e<o.remaining)}}function V(){if(M)return;M=!0;let e=P();window.clearInterval(N),window.removeEventListener(`pagehide`,V),window.removeEventListener(`aandehul:studio-hidden`,V),document.removeEventListener(`visibilitychange`,B),window.removeEventListener(`aandehul:pebble-speaking`,ue),L(),D&&D.close().catch(()=>{}),a.open&&a.close(),a.remove(),xe=null,j||pe(e>=x,e)}m.addEventListener(`click`,()=>{if(C===null)C=performance.now(),w=-1,N=window.setInterval(B,100);else{if(B(),j)return;S=P(),C=null,window.clearInterval(N),L(),D?.state===`running`&&D.suspend().catch(()=>{}),c.dataset.pose=`paused`,f.textContent=`På pause`,p.textContent=`Jeg venter lige her. Fortsæt, når du har lyst.`}fe(),B()}),_.addEventListener(`click`,()=>{E=!E,we(ve,E),I(),E?F(392):D?.state===`running`&&D.suspend().catch(()=>{})}),o(`.coach-ambient`).addEventListener(`click`,()=>{ce(()=>{j&&a.open&&g.focus({preventScroll:!0})})}),v.addEventListener(`click`,()=>{O=!O,we(ye,O),de(),O?R(j):(L(),y.hidden=!0)}),b.addEventListener(`change`,()=>{x=Number(b.value)*60,oe.max=x,ae.textContent=Se(x),B()}),h.addEventListener(`click`,V),g.addEventListener(`click`,V),a.addEventListener(`cancel`,e=>{e.preventDefault(),V()}),a.addEventListener(`close`,V),a.addEventListener(`click`,e=>{if(e.target!==a)return;let t=a.getBoundingClientRect();(e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom)&&V()}),window.addEventListener(`pagehide`,V,{once:!0}),window.addEventListener(`aandehul:studio-hidden`,V),document.addEventListener(`visibilitychange`,B),_e(),window.addEventListener(`aandehul:pebble-speaking`,ue),de(),oe.max=x,ae.textContent=Se(x),fe(),I(),document.body.appendChild(a),a.showModal(),m.focus({preventScroll:!0}),B(),N=window.setInterval(B,100)}var De=[{id:`pusterum`,label:`Mit pusterum`,icon:`house`},{id:`bibliotek`,label:`Øvelsesbibliotek`,icon:`book-open`},{id:`favoritter`,label:`Mine favoritter`,icon:`heart`},{id:`historik`,label:`Min historik`,icon:`history`}],Oe={pusterum:`Mit pusterum`,bibliotek:`Øvelsesbibliotek`,favoritter:`Mine favoritter`,historik:`Min historik`,pebble:`Min skrivebordsven`,indstillinger:`Indstillinger`},ke={"rolig-vejrtraekning":`breath`,kropsscanning:`body`,"giv-slip-paa-dagen":`evening`,"et-roligt-oejeblik":`pond`,"blid-udanding":`reeds`,"lette-skuldre":`hills`},Ae={Vejrtrækning:`wind`,Afspænding:`flower-2`,Meditation:`moon-star`},H=[{id:`urolig`,title:`Urolig`,icon:`frown`,reply:`Jeg bliver lige her. Vi kan tage ét åndedrag ad gangen.`},{id:`traet`,title:`Træt`,icon:`cloud-moon`,reply:`Du må gerne hvile lidt. Jeg holder dig med selskab.`},{id:`tilpas`,title:`Tilpas`,icon:`smile`,reply:`Hvor rart. Skal vi bare blive her et øjeblik?`},{id:`glad`,title:`Glad`,icon:`sun`,reply:`Nu smiler jeg også. Lad os nyde det et øjeblik.`}],je=new Intl.DateTimeFormat(`da-DK`,{weekday:`long`,day:`numeric`,month:`long`}),Me=new Intl.DateTimeFormat(`da-DK`,{hour:`2-digit`,minute:`2-digit`});function Ne(e){let t=je.format(e);return t.charAt(0).toUpperCase()+t.slice(1)}var U=e=>[e.getFullYear(),String(e.getMonth()+1).padStart(2,`0`),String(e.getDate()).padStart(2,`0`)].join(`-`),W=new Map;function Pe(e){if(W.has(e))return W.get(e);try{return localStorage.getItem(e)}catch{return null}}function Fe(e,t){try{localStorage.setItem(e,t),W.delete(e)}catch{W.set(e,t)}}function Ie(){try{let e=JSON.parse(Pe(`aandehul.checkins.v1`)||`{}`);return Object.fromEntries(Object.entries(e).filter(([e,t])=>/^\d{4}-\d{2}-\d{2}$/.test(e)&&H.some(e=>e.id===t)))}catch{return{}}}var G=window.chrome?.webview,K=null,Le=window.matchMedia(`(display-mode: standalone)`).matches||!!navigator.standalone,Re=`Alle`,q=Ve(),ze=U(new Date);document.documentElement.classList.add(`js`);var J=document.querySelector(`#app`),Be=()=>Ie()[U(new Date)];document.documentElement.classList.toggle(`less-motion`,Pe(`aandehul.less-motion`)===`on`);function Ve(){let e=location.hash.slice(1);return Object.hasOwn(Oe,e)?e:`pusterum`}var He=(e=``)=>`<img src="/images/pebble.png" class="${e}" alt="" draggable="false">`,Ue=()=>`<a href="#pusterum" class="brand" aria-label="Åndehul, til forsiden">${He(`brand-mark`)}<span>Åndehul</span></a>`,We=[{clip:`greeting`,words:`Hej med dig. Skal vi tage en lille pause sammen?`},{clip:`little-stone`,words:`Selv en sten som mig kan godt lide en lille pause.`},{clip:`welcome`,words:`Lad skuldrene hvile. Vi tager det i dit tempo.`}],Ge=0,Y=null,Ke;function qe(e){return`<button type="button" data-action="greet" class="pebble-greeting ${e}-friend" aria-label="Hør en hilsen fra Pebble" title="Hør Pebbles syntetiske danske stemme">
    <span class="greet-bubble">${d(`volume-2`)}<span>Hils på mig</span></span>
    <span class="friend-shadow"></span><span class="friend-body">${le(`awake`)}</span>
  </button>`}function Je(e,t,n){return`<a class="nav-link" href="#${e}" data-nav="${e}">${d(n)}<span>${t}</span></a>`}J.innerHTML=`
  <a class="skip" href="#content">Gå til indhold</a>
  <header class="mobile-bar">${Ue()}<button class="circle-button" data-action="menu" aria-label="Åbn menu" aria-expanded="false" aria-controls="sidebar">${d(`menu`)}</button></header>
  <button class="shade" aria-label="Luk menu" tabindex="-1" data-action="close-menu" hidden></button>
  <aside class="sidebar" id="sidebar" aria-label="Hovedmenu">
    <div class="sidebar-brand">${Ue()}<button data-action="close-menu" aria-label="Luk menu" class="menu-close circle-button">${d(`x`)}</button></div>
    <nav class="main-nav" aria-label="Sider">${De.map(e=>Je(e.id,e.label,e.icon)).join(``)}</nav>
    <div class="sidebar-foot">
      <a href="#pebble" class="friend-card" data-nav="pebble">
        <div class="pet-habitat">${He()}</div>
        <span class="friend-title">Din skrivebordsven</span>
        <span class="friend-link">Mød Pebble ${d(`arrow-right`)}</span>
      </a>
      ${Je(`indstillinger`,`Indstillinger`,`settings`)}
    </div>
  </aside>
  <main id="content" tabindex="-1">
    <div class="content-inner">
      <header class="page-header">
        <div><div class="date-line">${d(`sun`)}<span id="today"></span></div><h1 id="page-title"></h1></div>
        <button class="sound-button" data-action="sound" aria-haspopup="dialog"></button>
      </header>
      <div id="view"></div>
    </div>
  </main>
  <dialog id="utility" aria-labelledby="utility-heading"></dialog>
  <div class="announcer" aria-live="polite" role="status"></div>`;var X=J.querySelector(`#view`),Z=J.querySelector(`#utility`),Ye=e=>{J.querySelector(`.announcer`).textContent=e};function Xe(e){let t=o(e.id),n=ke[e.id];return`<article class="exercise-card cover-${n}">
      <button class="exercise-open" data-start="${e.id}" aria-label="Start ${e.title}, ${e.minutes} minutter">
        <span class="cover"><img src="/images/${n}.webp" alt="" loading="lazy"></span>
        <span class="card-copy">
          <span class="category">${d(Ae[e.category])}${e.category}</span>
          <span class="card-title">${e.title}</span>
          <span class="card-description">${e.description}</span>
          <span class="card-bottom"><span class="time">${d(`clock`)}${e.minutes} min</span><span class="small-play">${d(`play`)}</span></span>
        </span>
      </button>
      <button class="favorite ${t?`is-saved`:``}" data-favorite="${e.id}" aria-label="${t?`Fjern`:`Gem`} ${e.title} ${t?`fra`:`i`} favoritter" aria-pressed="${t}">${d(`heart`)}</button>
    </article>`}var Ze=e=>`<div class="exercise-grid">${e.map(Xe).join(``)}</div>`;function Qe(){let t=Be(),n=H.find(e=>e.id===t)?.reply;return`<section class="hero" aria-labelledby="hero-title">
      <div class="hero-content">
        <span class="feature-label">${d(`sunrise`)}Dagens pause</span>
        <h2 id="hero-title">Et øjebliks ro.</h2>
        <p data-greeting-line>Jeg hedder Pebble. Skal vi trække vejret sammen?</p>
        <div class="hero-actions"><button class="primary" data-start="rolig-vejrtraekning">${d(`play`)}Start en pause</button><span class="time">${d(`clock`)}3 min</span></div>
      </div>${qe(`meadow`)}
    </section>
    <section class="suggestions" aria-labelledby="suggested">
      <div class="section-title"><h2 id="suggested">Find din øvelse</h2><a href="#bibliotek" class="text-link">Se alle øvelser ${d(`arrow-right`)}</a></div>
      ${Ze(e.slice(0,3))}
    </section>
    <section class="checkin" aria-labelledby="checkin-heading">
      <div class="checkin-intro"><span class="checkin-symbol">${d(`notebook-pen`)}</span><div><h2 id="checkin-heading">Hvordan har du det?</h2><p>${n?`Pebble siger “`+n+`”`:`Tag et øjeblik og mærk efter.`}</p></div></div>
      <div class="mood-options">${H.map(e=>`<button data-mood="${e.id}" aria-pressed="${t===e.id}" class="mood">${d(e.icon)}${e.title}</button>`).join(``)}</div>
    </section>`}function $e(){return`<p class="page-description">Vælg en øvelse, der passer til dig lige nu.</p>
    <div class="filter-bar" role="group" aria-label="Filtrér øvelser">${[`Alle`,`Vejrtrækning`,`Meditation`,`Afspænding`].map(e=>`<button data-filter="${e}" aria-pressed="${Re===e}">${e}</button>`).join(``)}</div>
    ${Ze(e.filter(e=>Re===`Alle`||e.category===Re))}`}function et(e,t,n){return`<div class="empty-state"><span class="empty-symbol">${d(e)}</span><h2>${t}</h2><p>${n}</p><a class="primary" href="#bibliotek">Udforsk øvelser ${d(`arrow-right`)}</a></div>`}function tt(){let t=e.filter(e=>o(e.id));return t.length?`<p class="page-description">Dine gemte øvelser, samlet ét sted.</p>${Ze(t)}`:et(`heart`,`Plads til dine favoritter`,`Tryk på hjertet ved en øvelse, du gerne vil vende tilbage til.`)}function nt(){let t=l(),n=Ie(),r=[...new Set([...t.map(e=>U(new Date(e.finishedAt))),...Object.keys(n)])].sort().reverse();return r.length?`<p class="page-description">Et tilbageblik på de pauser, du har givet dig selv.</p>`+r.map(r=>{let i=H.find(e=>e.id===n[r]);return`<section class="history-day"><h2>${Ne(new Date(r+`T12:00:00`))}</h2>
      ${i?`<div class="history-row"><span class="row-symbol">${d(i.icon)}</span><div><strong>${i.title}</strong><small>Dagens indtjekning</small></div></div>`:``}
      ${t.filter(e=>U(new Date(e.finishedAt))===r).map(t=>{let n=e.find(e=>e.id===t.exerciseId),r=Math.floor(t.seconds/60),i=t.seconds%60,a=r?r+` min`+(i?` `+i+` sek`:``):i+` sek`;return`<div class="history-row"><span class="row-symbol">${d(Ae[n?.category||`Vejrtrækning`])}</span><div><strong>${n?.title||`Vejrtrækning med Pebble`}</strong><small>${a} · ${t.completed?`Gennemført`:`Afsluttet undervejs`}</small></div><time>${Me.format(new Date(t.finishedAt))}</time></div>`}).join(``)}</section>`}).join(``):et(`history`,`Her begynder din historik`,`Dine pauser og daglige indtjekninger dukker op her.`)}function rt(){return`<section class="companion-view"><div class="companion-art">${qe(`portrait`)}</div>
      <div><h2>Hej, jeg er Pebble.</h2><p data-greeting-line>Jeg er en lille sten med god tid. Når jeg løfter mig, trækker vi vejret ind. Når jeg synker ned, puster vi ud.</p>
      <button class="primary" data-start="rolig-vejrtraekning" data-minutes="1">${d(`wind`)}Ét minut med mig</button>
      </div></section>
      <section class="detail-block"><h2>Pebble på skrivebordet</h2><p>På Windows kan Pebble sidde oven på dine andre vinduer. Klik på stenen for en pause, eller træk den hen, hvor den skal sidde.</p><p>Pebbles danske stemme er lavet med talesyntesen Røst. Alle replikker følger med appen, så du også kan høre dem offline.</p>
      ${G?`<div class="desktop-actions"><button class="secondary" data-action="show-pebble">${d(`monitor`)}Vis Pebble på skrivebordet</button><button class="secondary" data-action="start-breathing">${d(`wind`)}Træk vejret med Pebble</button></div>`:`<a class="secondary" href="/downloads/Aandehul-Windows.zip" download>${d(`download`)}Hent til Windows</a><p class="small-note">Pak ZIP-filen ud, og start Aandehul.exe. Til Windows 10 og 11 (x64) med <a href="https://dotnet.microsoft.com/download/dotnet/10.0" target="_blank" rel="noreferrer">.NET 10 Desktop Runtime</a> og Microsoft Edge WebView2.</p>`}
      </section>`}function it(){let e=document.documentElement.classList.contains(`less-motion`);return`<section class="settings-list">
    <div class="settings-row"><span class="row-symbol">${d(`leaf`)}</span><div><strong>Mindre bevægelse</strong><p>Gør animationerne i øvelserne mere stille.</p></div><button data-action="motion" role="switch" aria-checked="${e}" aria-label="Mindre bevægelse" class="switch"><span></span></button></div>
    <div class="settings-row"><span class="row-symbol">${d(`headphones`)}</span><div><strong>Lydmiljø</strong><p>Vælg musik eller naturlyde til din pause.</p></div><button class="secondary" data-action="sound">Vælg lyd</button></div>
    ${G?``:`<div class="settings-row"><span class="row-symbol">${d(`download`)}</span><div><strong>Installér Åndehul</strong><p>Åbn dit pusterum som app på denne enhed.</p></div>${Le?`<span class="installed">Installeret</span>`:`<button class="secondary" data-action="install">Installér</button>`}</div>`}
    <div class="settings-row"><span class="row-symbol">${d(`monitor`)}</span><div><strong>Lokalt på din enhed</strong><p>Dine favoritter, pauser og indtjekninger gemmes i denne app.</p></div></div>
  </section>`}function at(){let{selected:e}=b(),t=e!==`off`,n=J.querySelector(`.sound-button`);n.classList.toggle(`playing`,t);let r=m.find(t=>t.id===e)?.name??`Lydmiljø`;n.title=t?`Lydmiljø · `+r:r,n.setAttribute(`aria-label`,t?`Åbn lydmiljø. Spiller `+r:`Lydmiljø`),n.innerHTML=d(t?`audio-lines`:`volume-2`)+`<span>`+r+`</span>`}window.addEventListener(`aandehul:ambient-change`,()=>{at(),G?.postMessage(b().selected===`off`?`ambient-stopped`:`ambient-playing`)}),G?.addEventListener(`message`,e=>{switch(e.data?.type){case`stop-ambient`:C(`off`);break;case`companion-speaking`:ae(e.data.active===!0);break;case`studio-hidden`:lt(),window.dispatchEvent(new Event(`aandehul:studio-hidden`))}});function Q(){lt(),document.title=Oe[q]+` · Åndehul`,J.querySelector(`#page-title`).textContent=Oe[q],J.querySelector(`#today`).textContent=Ne(new Date),J.querySelectorAll(`[data-nav]`).forEach(e=>{e.dataset.nav===q?e.setAttribute(`aria-current`,`page`):e.removeAttribute(`aria-current`)}),X.innerHTML={pusterum:Qe,bibliotek:$e,favoritter:tt,historik:nt,pebble:rt,indstillinger:it}[q](),at()}function ot(e,t){Z.innerHTML=`<div class="dialog-head"><h2 id="utility-heading">${e}</h2><button data-action="close" class="circle-button" aria-label="Luk">${d(`x`)}</button></div>${t}`,Z.open||Z.showModal()}function $(e){J.classList.toggle(`menu-open`,e),J.querySelector(`main`).inert=e,J.querySelector(`.mobile-bar`).inert=e,J.querySelector(`.skip`).inert=e;let t=J.querySelector(`[data-action="menu"]`);t.setAttribute(`aria-expanded`,String(e)),J.querySelector(`.shade`).hidden=!e,e?J.querySelector(`.menu-close`).focus():window.matchMedia(`(max-width: 820px)`).matches&&J.querySelector(`#sidebar`).contains(document.activeElement)&&t.focus()}function st(e,t){X.querySelector(`[${e}="${CSS.escape(t)}"]`)?.focus({preventScroll:!0})}function ct(e){e.querySelector(`.pebble-figure`)?.classList.remove(`is-talking`);let t=e.querySelector(`.pebble-figure`);t.dataset.pose=`happy`,e.querySelector(`.greet-bubble span`).textContent=`Hils igen`,e.setAttribute(`aria-label`,`Hør en ny hilsen fra Pebble`),Ke=window.setTimeout(()=>{t.dataset.pose=`awake`},1400)}function lt(){if(window.clearTimeout(Ke),!Y)return;let e=Y;Y=null,_e(),ct(e)}async function ut(e){if(Y){lt();return}window.clearTimeout(Ke);let t=Ge++,n=We[t%We.length];Y=e,X.querySelector(`[data-greeting-line]`).textContent=n.words,e.querySelector(`.pebble-figure`).dataset.pose=`listening`,e.querySelector(`.greet-bubble span`).textContent=`Stop hilsen`,e.setAttribute(`aria-label`,`Stop Pebbles hilsen`),!await he(n.clip)&&Y===e&&Ge===t+1&&(lt(),Ye(n.words))}window.addEventListener(`aandehul:pebble-speaking`,e=>{Y&&Y.querySelector(`.pebble-figure`).classList.toggle(`is-talking`,e.detail)}),window.addEventListener(`aandehul:pebble-voice-ended`,()=>{Y&&=(ct(Y),null)}),J.addEventListener(`click`,async e=>{let t=e.target.closest(`button,a`);if(!t)return;let{action:n,start:r,favorite:i,mood:a,filter:o}=t.dataset;if(r)lt(),Ee(r,t.dataset.minutes?Number(t.dataset.minutes):void 0);else if(i){let e=[...X.querySelectorAll(`[data-favorite]`)].indexOf(t),n=s(i);if(q===`favoritter`&&!n){let t=[...X.querySelectorAll(`[data-favorite]`)];(t[Math.min(e,t.length-1)]??X.querySelector(`.empty-state a`))?.focus({preventScroll:!0})}Ye(n?`Gemt i dine favoritter.`:`Fjernet fra dine favoritter.`)}else if(a&&H.some(e=>e.id===a)){let e=Ie();e[U(new Date)]=a,Fe(`aandehul.checkins.v1`,JSON.stringify(e)),Q(),st(`data-mood`,a),Ye(`Din indtjekning er gemt.`)}else if(o)Re=o,Q(),st(`data-filter`,o);else if(t.classList.contains(`skip`))e.preventDefault(),J.querySelector(`#content`).focus();else switch(t.matches(`[data-nav],.brand`)&&$(!1),n){case`greet`:await ut(t);break;case`menu`:$(!0);break;case`close-menu`:$(!1);break;case`close`:Z.close();break;case`sound`:ce();break;case`show-pebble`:case`start-breathing`:G?.postMessage(n);break;case`motion`:{let e=document.documentElement.classList.toggle(`less-motion`);Fe(`aandehul.less-motion`,e?`on`:`off`),t.setAttribute(`aria-checked`,String(e));break}case`install`:if(K){let e=K;K=null,await e.prompt(),(await e.userChoice).outcome===`accepted`&&(Le=!0,Q())}else ot(`Installér Åndehul`,/iPad|iPhone|iPod/.test(navigator.userAgent)||navigator.platform===`MacIntel`&&navigator.maxTouchPoints>1?`<p>Åbn Åndehul i Safari. Tryk på Del og vælg Føj til hjemmeskærm. Åbn derefter Åndehul fra det nye ikon.</p>`:`<p>Åbn browserens menu og vælg Installér app eller Føj til startskærm, hvis muligheden vises. På en computer kan du åbne Åndehul i Chrome eller Edge for at installere den.</p>`)}}),Z.addEventListener(`click`,e=>{if(e.target!==Z)return;let t=Z.getBoundingClientRect();(e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom)&&Z.close()}),window.addEventListener(`hashchange`,()=>{q=Ve(),$(!1),Q(),window.scrollTo(0,0),J.querySelector(`#content`).focus({preventScroll:!0})}),window.addEventListener(`keydown`,e=>{if(J.classList.contains(`menu-open`)&&(e.key===`Escape`&&$(!1),e.key===`Tab`)){let t=[...J.querySelectorAll(`#sidebar a,#sidebar button`)].filter(e=>e.offsetParent!==null);e.shiftKey&&document.activeElement===t[0]?(e.preventDefault(),t.at(-1)?.focus()):!e.shiftKey&&document.activeElement===t.at(-1)&&(e.preventDefault(),t[0]?.focus())}}),window.matchMedia(`(max-width: 820px)`).addEventListener(`change`,()=>$(!1)),window.addEventListener(`aandehul:change`,()=>{if(q===`historik`){Q();return}let t=[...X.querySelectorAll(`[data-favorite]`)];if(q===`favoritter`&&(t.length!==e.filter(e=>o(e.id)).length||t.some(e=>!o(e.dataset.favorite))))Q();else for(let n of t){let t=e.find(e=>e.id===n.dataset.favorite);if(!t)continue;let r=o(t.id);n.classList.toggle(`is-saved`,r),n.setAttribute(`aria-pressed`,String(r)),n.setAttribute(`aria-label`,r?`Fjern `+t.title+` fra favoritter`:`Gem `+t.title+` i favoritter`)}}),window.addEventListener(`storage`,e=>{e.key===null?W.clear():W.delete(e.key),(e.key===null||e.key===`aandehul.less-motion`)&&(document.documentElement.classList.toggle(`less-motion`,Pe(`aandehul.less-motion`)===`on`),q===`indstillinger`&&Q()),e.key!==null&&e.key!==`aandehul.checkins.v1`||q!==`historik`&&q!==`pusterum`||Q()}),window.addEventListener(`beforeinstallprompt`,e=>{e.preventDefault(),K=e}),window.addEventListener(`appinstalled`,()=>{Le=!0,K=null,q===`indstillinger`&&Q()});function dt(){let e=U(new Date);ze!==e&&(ze=e,Q())}window.addEventListener(`focus`,dt),window.setInterval(dt,6e4),Q();