(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[{id:`rolig-vejrtraekning`,title:`Rolig vejrtrækning`,description:`Følg en blid rytme, ét åndedrag ad gangen.`,category:`Vejrtrækning`,minutes:3,durations:[1,3,5],breath:{inhale:4,exhale:4},steps:[{title:`Træk vejret ind`,instruction:`Lad luften komme stille ind i dit eget tempo.`},{title:`Pust langsomt ud`,instruction:`Lad skuldrene hvile, mens luften slipper ud.`}]},{id:`kropsscanning`,title:`Kropsscanning`,description:`Lad opmærksomheden gå på besøg i kroppen.`,category:`Afspænding`,minutes:5,durations:[3,5,10],steps:[{title:`Find dig til rette`,instruction:`Mærk fladen under dig. Lad hænderne hvile, hvor de har lyst.`},{title:`Mærk dine fødder`,instruction:`Læg mærke til tæerne, hælene og kontakten med gulvet.`},{title:`Giv benene plads`,instruction:`Flyt opmærksomheden langsomt fra anklerne op mod hofterne.`},{title:`Hvil i midten`,instruction:`Læg mærke til den lille bevægelse i maven, når du trækker vejret.`},{title:`Mærk dine skuldre`,instruction:`Følg armene helt ud til fingerspidserne. Måske føles én hånd varmere.`},{title:`Vend stille tilbage`,instruction:`Mærk kroppen som en helhed. Bevæg forsigtigt fingre og tæer.`,pose:`awake`}]},{id:`giv-slip-paa-dagen`,title:`Giv slip på dagen`,description:`En stille meditation til dagens sidste stund.`,category:`Meditation`,minutes:7,durations:[3,7,10],steps:[{title:`Land her`,instruction:`Lad blikket hvile på et roligt punkt, eller luk øjnene et øjeblik.`},{title:`Lad dagen passere`,instruction:`Måske dukker et øjeblik fra dagen op. Lad det ligge et øjeblik.`,pose:`rest`},{title:`Mærk et åndedrag`,instruction:`Følg luften ind og ud. Du må gerne vende tilbage til åndedrættet mange gange.`,pose:`rest`},{title:`Find én lille ting`,instruction:`Tænk på en lille ting fra i dag, som var rar. Bliv lidt ved den.`,pose:`happy`},{title:`Tag roen med`,instruction:`Mærk rummet omkring dig, og kom langsomt tilbage i dit eget tempo.`,pose:`awake`}]},{id:`et-roligt-oejeblik`,title:`Et roligt øjeblik`,description:`Find et lille holdepunkt i lydene omkring dig.`,category:`Meditation`,minutes:3,durations:[1,3,5],steps:[{title:`Sæt dig godt`,instruction:`Lad kroppen finde en rar stilling. Mærk dine fødder mod underlaget.`},{title:`Lyt til rummet`,instruction:`Læg mærke til en lyd i nærheden. Lad den komme og gå.`},{title:`Lyt lidt længere væk`,instruction:`Måske kan du høre noget udenfor. Vend roligt tilbage, når tankerne vandrer.`},{title:`Vend tilbage`,instruction:`Lad blikket glide rundt i rummet. Giv dig tid til at komme videre.`,pose:`awake`}]},{id:`blid-udanding`,title:`Blid udånding`,description:`Giv udåndingen lidt ekstra tid og plads.`,category:`Vejrtrækning`,minutes:2,durations:[1,2,5],breath:{inhale:3,exhale:5},steps:[{title:`Træk vejret ind`,instruction:`Tag en let indånding i en rytme, som passer dig.`},{title:`Lad luften slippe ud`,instruction:`Giv udåndingen lidt længere tid, så længe det føles rart.`}]},{id:`lette-skuldre`,title:`Lette skuldre`,description:`En lille afspænding ved skrivebordet.`,category:`Afspænding`,minutes:3,durations:[1,3,5],steps:[{title:`Find en rar stilling`,instruction:`Lad fødderne hvile mod gulvet og armene ligge løst langs siden.`},{title:`Mærk dine skuldre`,instruction:`Læg mærke til, hvordan skuldrene føles lige nu.`},{title:`Løft ganske let`,instruction:`Hvis det føles rart, så løft langsomt skuldrene en smule og lad dem synke igen.`},{title:`Lad armene hvile`,instruction:`Mærk vægten i hænderne. Giv kæben lidt plads.`},{title:`Find tilbage`,instruction:`Bevæg forsigtigt fingrene og lad blikket vende tilbage til rummet.`,pose:`awake`}]}],t=`aandehul.session.v1.`,n=`aandehul.favorite.v1.`,r=new Map;function i(e){if(r.has(e))return r.get(e);try{return localStorage.getItem(e)}catch{return null}}function a(e,t){let n=!0;try{localStorage.setItem(e,t),r.delete(e)}catch{r.set(e,t),n=!1}return window.dispatchEvent(new Event(`aandehul:change`)),n}typeof window<`u`&&window.addEventListener(`storage`,e=>{(e.key===null||e.key.startsWith(t)||e.key.startsWith(n))&&(e.key===null?r.clear():r.delete(e.key),window.dispatchEvent(new Event(`aandehul:change`)))});function o(e){return i(n+e)===`true`}function s(t){if(!e.some(e=>e.id===t))return!1;let r=!o(t);return a(n+t,String(r)),r}function c(t){if(!t||typeof t!=`object`)return!1;let n=t;return typeof n.exerciseId==`string`&&e.some(e=>e.id===n.exerciseId)&&typeof n.seconds==`number`&&Number.isFinite(n.seconds)&&n.seconds>0&&typeof n.startedAt==`string`&&Number.isFinite(Date.parse(n.startedAt))&&typeof n.finishedAt==`string`&&Number.isFinite(Date.parse(n.finishedAt))&&typeof n.completed==`boolean`}function l(){let e=new Set(r.keys());try{for(let n=0;n<localStorage.length;n++){let r=localStorage.key(n);r?.startsWith(t)&&e.add(r)}}catch{}let n=[];for(let r of e)if(r.startsWith(t))try{let e=JSON.parse(i(r)??`null`);c(e)&&n.push(e)}catch{}return n.sort((e,t)=>Date.parse(t.finishedAt)-Date.parse(e.finishedAt))}function u(e){if(!c(e))return!1;let n=t+e.exerciseId+`.`+e.startedAt,o=JSON.stringify(e);return!r.has(n)&&i(n)===o||a(n,o)}if(typeof window<`u`){let e=window.chrome?.webview;e&&(e.addEventListener(`message`,t=>{let n=t.data;n?.type===`pebble-session`&&c(n.record)&&u(n.record)&&e.postMessage(`pebble-saved:`+n.record.startedAt)}),e.postMessage(`pebble-ready`))}function d(e,t,n){if(e.breath){let{inhale:r,exhale:i}=e.breath,a=t%(r+i),o=a<r,s=o?r:i,c=o?a:a-r,l=c/s,u=(1-Math.cos(Math.PI*l))/2;return{...e.steps[+!o],index:+!o,expansion:o?u:1-u,phase:{direction:o?`inhale`:`exhale`,seconds:s,remaining:Math.ceil(Math.min(s-c,n-t)),fraction:l}}}let r=Math.min(e.steps.length-1,Math.floor(t/n*e.steps.length));return{...e.steps[r],index:r,expansion:(1-Math.cos(t/5))/2}}var ee=Object.assign({"./icons/arrow-right.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-arrow-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
  <path d="m12 5 7 7-7 7" />
</svg>
`,"./icons/audio-lines.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-audio-lines"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 10v3" />
  <path d="M6 6v11" />
  <path d="M10 3v18" />
  <path d="M14 8v7" />
  <path d="M18 5v13" />
  <path d="M22 10v3" />
</svg>
`,"./icons/book-open.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-book-open"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 5v16" />
  <path d="M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z" />
</svg>
`,"./icons/check.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 6 9 17l-5-5" />
</svg>
`,"./icons/clock.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-clock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 6v6l4 2" />
</svg>
`,"./icons/cloud-moon.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-cloud-moon"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M13 16a3 3 0 0 1 0 6H7a5 5 0 1 1 4.9-6z" />
  <path d="M18.376 14.512a6 6 0 0 0 3.461-4.127c.148-.625-.659-.97-1.248-.714a4 4 0 0 1-5.259-5.26c.255-.589-.09-1.395-.716-1.248a6 6 0 0 0-4.594 5.36" />
</svg>
`,"./icons/cloud-rain.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-cloud-rain"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242" />
  <path d="M16 14v6" />
  <path d="M8 14v6" />
  <path d="M12 16v6" />
</svg>
`,"./icons/download.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-download"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 15V3" />
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
  <path d="m7 10 5 5 5-5" />
</svg>
`,"./icons/flower-2.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-flower-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 5a3 3 0 1 1 3 3m-3-3a3 3 0 1 0-3 3m3-3v1M9 8a3 3 0 1 0 3 3M9 8h1m5 0a3 3 0 1 1-3 3m3-3h-1m-2 3v-1" />
  <circle cx="12" cy="8" r="2" />
  <path d="M12 10v12" />
  <path d="M12 22c4.2 0 7-1.667 7-5-4.2 0-7 1.667-7 5Z" />
  <path d="M12 22c-4.2 0-7-1.667-7-5 4.2 0 7 1.667 7 5Z" />
</svg>
`,"./icons/frown.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-frown"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 10V9" />
  <path d="M9 10V9" />
  <path d="M9 16a5 5 0 016 0" />
  <circle cx="12" cy="12" r="10" />
</svg>
`,"./icons/headphones.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-headphones"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3" />
</svg>
`,"./icons/heart.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-heart"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5" />
</svg>
`,"./icons/history.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-history"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
  <path d="M3 3v5h5" />
  <path d="M12 7v5l4 2" />
</svg>
`,"./icons/house.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-house"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8" />
  <path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
</svg>
`,"./icons/leaf.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-leaf"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 20a10 10 0 0010-10 25.9 25.9 0 00-1.04-7.281 1 1 0 00-1.755-.325C15.833 5.5 13 5.5 9.8 6.1A7 7 0 0011 20" />
  <path d="M2 21a5 5 0 012.911-4.544C7.613 15.212 8.351 15.24 11 13" />
</svg>
`,"./icons/menu.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-menu"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 5h16" />
  <path d="M4 12h16" />
  <path d="M4 19h16" />
</svg>
`,"./icons/monitor.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-monitor"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="14" x="2" y="3" rx="2" />
  <line x1="8" x2="16" y1="21" y2="21" />
  <line x1="12" x2="12" y1="17" y2="21" />
</svg>
`,"./icons/moon-star.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-moon-star"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 5h4" />
  <path d="M20 3v4" />
  <path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401" />
</svg>
`,"./icons/notebook-pen.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-notebook-pen"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" />
  <path d="M2 6h4" />
  <path d="M2 10h4" />
  <path d="M2 14h4" />
  <path d="M2 18h4" />
  <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" />
</svg>
`,"./icons/pause.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-pause"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect x="14" y="3" width="5" height="18" rx="1" />
  <rect x="5" y="3" width="5" height="18" rx="1" />
</svg>
`,"./icons/play.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-play"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z" />
</svg>
`,"./icons/settings.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-settings"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915" />
  <circle cx="12" cy="12" r="3" />
</svg>
`,"./icons/smile.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-smile"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 10V9" />
  <path d="M16.472 15a6 6 0 01-8.943 0" />
  <path d="M9 10V9" />
  <circle cx="12" cy="12" r="10" />
</svg>
`,"./icons/sun.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-sun"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="4" />
  <path d="M12 2v2" />
  <path d="M12 20v2" />
  <path d="m4.93 4.93 1.41 1.41" />
  <path d="m17.66 17.66 1.41 1.41" />
  <path d="M2 12h2" />
  <path d="M20 12h2" />
  <path d="m6.34 17.66-1.41 1.41" />
  <path d="m19.07 4.93-1.41 1.41" />
</svg>
`,"./icons/sunrise.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-sunrise"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 2v8" />
  <path d="m4.93 10.93 1.41 1.41" />
  <path d="M2 18h2" />
  <path d="M20 18h2" />
  <path d="m19.07 10.93-1.41 1.41" />
  <path d="M22 22H2" />
  <path d="m8 6 4-4 4 4" />
  <path d="M16 18a4 4 0 0 0-8 0" />
</svg>
`,"./icons/volume-2.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-volume-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z" />
  <path d="M16 9a5 5 0 0 1 0 6" />
  <path d="M19.364 18.364a9 9 0 0 0 0-12.728" />
</svg>
`,"./icons/volume-x.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-volume-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 4.702a.7.7 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.7.7 0 0 0 11 19.298z" />
  <path d="m16.5 14.5 5-5" />
  <path d="m16.5 9.5 5 5" />
</svg>
`,"./icons/waves.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-waves"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 12q2.5 2 5 0t5 0 5 0 5 0" />
  <path d="M2 19q2.5 2 5 0t5 0 5 0 5 0" />
  <path d="M2 5q2.5 2 5 0t5 0 5 0 5 0" />
</svg>
`,"./icons/wind.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-wind"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.8 19.6A2 2 0 1 0 14 16H2" />
  <path d="M17.5 8a2.5 2.5 0 1 1 2 4H2" />
  <path d="M9.8 4.4A2 2 0 1 1 11 8H2" />
</svg>
`,"./icons/x.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 6 6 18" />
  <path d="m6 6 12 12" />
</svg>
`});function f(e){let t=ee[`./icons/`+e+`.svg`];return t?t.replace(`<svg`,`<svg aria-hidden="true" focusable="false"`):``}var p=[`body`,`sprout`,`eyes-rest`,`eyes-open`,`eyes-happy`,`mouth-smile`,`mouth-round`,`mouth-talk`];function te(e=`rest`){return`<span class="pebble-figure" data-pose="${e}" aria-hidden="true">${p.map(e=>`<img class="pebble-part part-${e}" src="./images/pebble-parts/${e}.png" alt="" draggable="false">`).join(``)}</span>`}var ne=new Map([[`kropsscanning`,6],[`giv-slip-paa-dagen`,5],[`et-roligt-oejeblik`,4],[`lette-skuldre`,5]]),m,h=0,g=``,_=!1,v,y,b,x=-1;function S(e){x!==e&&(x=e,document.documentElement.style.setProperty(`--pebble-jaw`,String(e)))}function re(){if(!m||!_)return;let e=y?.clips[g];if(e&&y){let t=Math.floor(m.currentTime*1e3/y.stepMs),n=Number(e[t]??0);S(Number.isFinite(n)?n/9:0)}else S(.28+.14*Math.sin(m.currentTime*17))}function C(e){_!==e&&(_=e,e?(re(),v=window.setInterval(re,40)):(clearInterval(v),S(0)),window.dispatchEvent(new CustomEvent(`aandehul:pebble-speaking`,{detail:e})))}function ie(){let e=new Audio;e.volume=.84,e.addEventListener(`playing`,()=>C(!e.paused));for(let t of[`pause`,`waiting`,`abort`])e.addEventListener(t,()=>C(!1));let t=()=>{if(!g)return;let e=g;g=``,C(!1),window.dispatchEvent(new CustomEvent(`aandehul:pebble-voice-ended`,{detail:e}))};return e.addEventListener(`ended`,()=>{e.ended&&t()}),e.addEventListener(`error`,()=>{e.error&&t()}),window.addEventListener(`pagehide`,ce),e}async function ae(){try{let e=await fetch(`/voice/mouth.json`);if(!e.ok)return;let t=await e.json();Number.isFinite(t?.stepMs)&&t.stepMs>0&&t.clips&&(y=t)}catch{}}async function w(e){let t=++h;m??=ie(),m.pause(),C(!1),b??=ae(),g=e,m.src=`/voice/${e}.mp3`;try{return await m.play(),t===h}catch{return!1}}function oe(e){return w(e)}function se(e,t){return!Number.isInteger(t)||t<0?Promise.resolve(!1):e===`rolig-vejrtraekning`||e===`blid-udanding`?t>1?Promise.resolve(!1):oe(t===0?`inhale`:`exhale`):t>=(ne.get(e)??0)?Promise.resolve(!1):w(`${e}-${t}`)}function ce(){h++,g=``,m?.pause(),C(!1)}var le=`aandehul.cue-sound.v1`,ue=`aandehul.cue-speech.v1`,T=new Map,de=null;function fe(e){return Math.floor(e/60)+`:`+String(e%60).padStart(2,`0`)}function pe(e,t=!1){let n=T.get(e);if(n!==void 0)return n;try{let n=localStorage.getItem(e);return n===null?t:n===`on`}catch{return t}}function me(e,t){try{localStorage.setItem(e,t?`on`:`off`),T.delete(e)}catch{T.set(e,t)}}function he(e,t){if(e.state!==`running`)return;let n=e.currentTime;for(let[r,i,a]of[[1,.065,1.65],[2,.012,.9]]){let o=e.createOscillator(),s=e.createGain();o.type=`sine`,o.frequency.value=t*r,s.gain.setValueAtTime(1e-4,n),s.gain.exponentialRampToValueAtTime(i,n+.055),s.gain.exponentialRampToValueAtTime(1e-4,n+a),o.connect(s).connect(e.destination),o.start(n),o.stop(n+a+.02),o.onended=()=>{o.disconnect(),s.disconnect()}}}function E(t,n){let r=e.find(e=>e.id===t);if(!r)return;if(de){de.focus();return}let i=n!==void 0&&r.durations.includes(n)?n:r.minutes,a=document.createElement(`dialog`);de=a,a.className=`coach-player`,a.dataset.practice=r.breath?`breathing`:r.category===`Meditation`?`meditation`:`relaxation`,a.setAttribute(`aria-labelledby`,`coach-exercise-title`),a.innerHTML=`
    <div class="coach-sheet">
      <div class="coach-topline">
        <span class="coach-category"></span>
        <button type="button" class="coach-speech" aria-pressed="false"><span class="coach-speech-icon" aria-hidden="true"></span>Pebbles stemme<span class="coach-speech-switch" aria-hidden="true"></span></button>
        <button type="button" class="coach-close" aria-label="Afslut og luk øvelsen" title="Afslut og luk">${f(`x`)}</button>
      </div>
      <h2 id="coach-exercise-title"></h2>
      <div class="coach-orbit" aria-hidden="true">
        <div class="coach-orbit-rings"></div>
        <span class="coach-air coach-air-left">${f(`wind`)}</span>
        <span class="coach-air coach-air-right">${f(`wind`)}</span>
        <div class="coach-stone-scene">
          <div class="coach-ground-shadow"></div>
          <div class="coach-pebble">${te(`rest`)}</div>
        </div>
      </div>
      <div class="coach-pace" role="timer" aria-live="off">
        <span class="coach-pace-direction" aria-hidden="true">${f(r.breath?`arrow-right`:`leaf`)}</span>
        <span class="coach-beats" aria-hidden="true"></span>
        <span class="coach-pace-label"></span>
      </div>
      <div class="coach-cue" aria-live="polite" aria-atomic="true">
        <h3></h3><p></p>
      </div>
      <div class="coach-session-controls">
        <div class="coach-time">
          <span class="coach-timer" role="timer" aria-label="Tid brugt">0:00</span>
          <progress class="coach-progress" aria-label="Forløbet tid"></progress>
          <span class="coach-total"></span>
        </div>
        <div class="coach-actions">
          <label class="coach-duration">Varighed
            <select aria-label="Varighed i minutter"></select>
          </label>
          <button type="button" class="coach-playback"></button>
          <button type="button" class="coach-sound" aria-pressed="false"></button>
        </div>
      </div>
      <p class="coach-voice-status" role="status" hidden></p>
      <button type="button" class="coach-done" hidden>Tilbage til mit åndehul</button>
    </div>`;let o=e=>a.querySelector(e),s=o(`.coach-orbit`),c=o(`.pebble-figure`),l=o(`.coach-pace`),ee=o(`.coach-pace-label`),p=o(`.coach-beats`),ne=o(`.coach-cue h3`),m=o(`.coach-cue p`),h=o(`.coach-session-controls`),g=o(`.coach-playback`),_=o(`.coach-close`),v=o(`.coach-done`),y=o(`.coach-sound`),b=o(`.coach-speech`),x=o(`.coach-voice-status`),S=o(`select`),re=o(`.coach-timer`),C=o(`.coach-total`),ie=o(`.coach-progress`);o(`.coach-category`).textContent=r.category,o(`#coach-exercise-title`).textContent=r.title,S.replaceChildren(...r.durations.map(e=>new Option(e+` min`,String(e)))),S.value=String(i);let ae=new Date().toISOString(),w=i*60,T=0,E=performance.now(),D=-1,O=-1,k=pe(le)&&typeof AudioContext<`u`,A,j=pe(ue,!0),M=0,N=-1,P=!1,F=!1,I=0;function L(){let e=E===null?0:(performance.now()-E)/1e3;return Math.min(w,T+e)}async function R(e){if(k&&typeof AudioContext<`u`)try{A??=new AudioContext,A.state===`suspended`&&await A.resume(),!F&&k&&(E!==null||P)&&he(A,e)}catch{F||(k=!1,z())}}function z(){y.innerHTML=f(k?`volume-2`:`volume-x`)+`<span>Klange</span>`,y.setAttribute(`aria-pressed`,String(k)),y.title=k?`Slå guideklange fra`:`Slå guideklange til`,y.setAttribute(`aria-label`,y.title),y.disabled=typeof AudioContext>`u`}function B(){M++,ce(),c.classList.remove(`is-talking`)}async function V(e=!1){if(!j||F||!e&&(E===null||D<0))return;let n=++M;x.hidden=!0,!await(e?oe(`complete`):se(t,D)).catch(()=>!1)&&n===M&&!F&&(x.textContent=`Stemmen kunne ikke starte. Du kan stadig følge teksten.`,x.hidden=!1)}function ge(e){let t=e.detail===!0;c.classList.toggle(`is-talking`,t&&j&&!F&&(E!==null||P))}function _e(){o(`.coach-speech-icon`).innerHTML=f(j?`volume-2`:`volume-x`),b.setAttribute(`aria-pressed`,String(j)),b.title=j?`Slå Pebbles stemme fra`:`Slå Pebbles danske stemme til`}function H(){let e=E===null;g.innerHTML=f(e?`play`:`pause`)+(e?`Fortsæt`:`Pause`),g.setAttribute(`aria-label`,e?`Fortsæt øvelsen`:`Sæt øvelsen på pause`),a.classList.toggle(`coach-paused`,e)}function U(e,n){let r=Math.floor(n);r>0&&u({exerciseId:t,startedAt:ae,finishedAt:new Date().toISOString(),seconds:r,completed:e})}function ve(){P||F||(P=!0,E=null,T=w,window.clearInterval(I),U(!0,w),B(),R(523.25),a.classList.add(`coach-finished`),c.dataset.pose=`happy`,s.style.setProperty(`--coach-expansion`,`0.2`),s.style.setProperty(`--pebble-breath`,`0.2`),s.style.setProperty(`--coach-flow`,`0`),l.hidden=!0,ne.textContent=`Din øvelse er færdig`,m.textContent=`Tak for stunden. Tag roen med dig.`,V(!0),h.hidden=!0,v.hidden=!1,_.setAttribute(`aria-label`,`Luk afspilleren`),_.title=`Luk`,v.focus({preventScroll:!0}))}function W(){if(F||P)return;let e=L();if(e>=w){ve();return}let t=Math.floor(e);if(t!==O&&(O=t,re.textContent=fe(t)),ie.value=e,E===null)return;let n=d(r,e,w),i=n.expansion.toFixed(4);s.style.setProperty(`--coach-expansion`,i),s.style.setProperty(`--pebble-breath`,i);let{phase:o}=n;if(o&&s.style.setProperty(`--coach-flow`,Math.sin(Math.PI*o.fraction).toFixed(4)),n.index!==D&&(D=n.index,ne.textContent=n.title,m.textContent=n.instruction,c.dataset.pose=o?.direction??n.pose??(r.category===`Meditation`?`listening`:`rest`),o?(a.dataset.phase=o.direction,l.setAttribute(`aria-label`,o.direction===`inhale`?`Tid tilbage af indåndingen`:`Tid tilbage af udåndingen`),p.childElementCount!==o.seconds&&p.replaceChildren(...Array.from({length:o.seconds},()=>document.createElement(`i`))),N=-1):ee.textContent=`Trin `+(n.index+1)+` af `+r.steps.length,V(),R(n.index%2==0?392:329.63)),o&&o.remaining!==N){N=o.remaining,ee.textContent=o.remaining+` sek.`;for(let[e,t]of Array.from(p.children).entries())t.classList.toggle(`remaining`,e<o.remaining)}}function G(){if(F)return;F=!0;let e=L();window.clearInterval(I),window.removeEventListener(`pagehide`,G),document.removeEventListener(`visibilitychange`,W),window.removeEventListener(`aandehul:pebble-speaking`,ge),B(),A&&A.close().catch(()=>{}),a.open&&a.close(),a.remove(),de=null,P||U(e>=w,e)}g.addEventListener(`click`,()=>{if(E===null)E=performance.now(),D=-1,I=window.setInterval(W,100);else{if(W(),P)return;T=L(),E=null,window.clearInterval(I),B(),A?.state===`running`&&A.suspend().catch(()=>{}),c.dataset.pose=`paused`,ne.textContent=`På pause`,m.textContent=`Jeg venter lige her. Fortsæt, når du har lyst.`}H(),W()}),y.addEventListener(`click`,()=>{k=!k,me(le,k),z(),k?R(392):A?.state===`running`&&A.suspend().catch(()=>{})}),b.addEventListener(`click`,()=>{j=!j,me(ue,j),_e(),j?V(P):(B(),x.hidden=!0)}),S.addEventListener(`change`,()=>{w=Number(S.value)*60,ie.max=w,C.textContent=fe(w),W()}),_.addEventListener(`click`,G),v.addEventListener(`click`,G),a.addEventListener(`cancel`,e=>{e.preventDefault(),G()}),a.addEventListener(`close`,G),a.addEventListener(`click`,e=>{if(e.target!==a)return;let t=a.getBoundingClientRect();(e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom)&&G()}),window.addEventListener(`pagehide`,G,{once:!0}),document.addEventListener(`visibilitychange`,W),ce(),window.addEventListener(`aandehul:pebble-speaking`,ge),_e(),ie.max=w,C.textContent=fe(w),H(),z(),document.body.appendChild(a),a.showModal(),g.focus({preventScroll:!0}),W(),I=window.setInterval(W,100)}var D=[{id:`off`,name:`Stilhed`,icon:`volume-x`},{id:`rain`,name:`Stille regn`,icon:`cloud-rain`},{id:`sea`,name:`Havbrus`,icon:`waves`},{id:`wind`,name:`Skovvind`,icon:`wind`}],O=`off`,k=null,A=null,j=0,M=.35;try{let e=localStorage.getItem(`aandehul.ambient.volume`);e!==null&&Number.isFinite(Number(e))&&(M=Math.max(0,Math.min(1,Number(e))))}catch{}var N=()=>({selected:O,level:M});function P(e){M=Math.max(0,Math.min(1,e)),k&&A&&A.gain.setTargetAtTime(M*.48,k.currentTime,.12);try{localStorage.setItem(`aandehul.ambient.volume`,String(M))}catch{}}async function F(e){let t=++j,n=k;if(n&&A&&(A.gain.setTargetAtTime(0,n.currentTime,.045),window.setTimeout(()=>{n.close().catch(()=>{})},200)),k=null,A=null,O=`off`,e===`off`)return;let r=new AudioContext;try{if(await r.resume(),t!==j){await r.close();return}let n=r.createBuffer(1,r.sampleRate*5,r.sampleRate),i=n.getChannelData(0),a=0;for(let t=0;t<i.length;t++){let n=Math.random()*2-1;a=(a+n*.035)/1.035,i[t]=e===`rain`?n*.55+a:a*4}let o=r.createBufferSource();o.buffer=n,o.loop=!0;let s=r.createBiquadFilter();s.type=`lowpass`,s.Q.value=.45,s.frequency.value=e===`rain`?2350:e===`sea`?1150:720;let c=r.createGain();c.gain.value=e===`rain`?.75:.6;let l=r.createOscillator(),u=r.createGain();u.gain.value=e===`rain`?.07:e===`sea`?.38:.21,l.frequency.value=e===`sea`?.093:.062,l.connect(u).connect(c.gain);let d=r.createGain();d.gain.value=0,o.connect(s).connect(c).connect(d).connect(r.destination),k=r,A=d,O=e,l.start(),o.start(),d.gain.setTargetAtTime(M*.48,r.currentTime,.4)}catch(e){throw r.state!==`closed`&&r.close().catch(()=>{}),e}}var I=[{id:`pusterum`,label:`Mit pusterum`,icon:`house`},{id:`bibliotek`,label:`Øvelsesbibliotek`,icon:`book-open`},{id:`favoritter`,label:`Mine favoritter`,icon:`heart`},{id:`historik`,label:`Min historik`,icon:`history`}],L={pusterum:`Mit pusterum`,bibliotek:`Øvelsesbibliotek`,favoritter:`Mine favoritter`,historik:`Min historik`,pebble:`Min skrivebordsven`,indstillinger:`Indstillinger`},R={"rolig-vejrtraekning":`breath`,kropsscanning:`body`,"giv-slip-paa-dagen":`evening`,"et-roligt-oejeblik":`pond`,"blid-udanding":`reeds`,"lette-skuldre":`hills`},z={Vejrtrækning:`wind`,Afspænding:`flower-2`,Meditation:`moon-star`},B=[{id:`urolig`,title:`Urolig`,icon:`frown`,reply:`Jeg bliver lige her. Vi kan tage ét åndedrag ad gangen.`},{id:`traet`,title:`Træt`,icon:`cloud-moon`,reply:`Du må gerne hvile lidt. Jeg holder dig med selskab.`},{id:`tilpas`,title:`Tilpas`,icon:`smile`,reply:`Hvor rart. Skal vi bare blive her et øjeblik?`},{id:`glad`,title:`Glad`,icon:`sun`,reply:`Nu smiler jeg også. Lad os nyde det et øjeblik.`}],V=new Intl.DateTimeFormat(`da-DK`,{weekday:`long`,day:`numeric`,month:`long`}),ge=new Intl.DateTimeFormat(`da-DK`,{hour:`2-digit`,minute:`2-digit`});function _e(e){let t=V.format(e);return t.charAt(0).toUpperCase()+t.slice(1)}var H=e=>[e.getFullYear(),String(e.getMonth()+1).padStart(2,`0`),String(e.getDate()).padStart(2,`0`)].join(`-`),U=new Map;function ve(e){if(U.has(e))return U.get(e);try{return localStorage.getItem(e)}catch{return null}}function W(e,t){try{localStorage.setItem(e,t),U.delete(e)}catch{U.set(e,t)}}function G(){try{let e=JSON.parse(ve(`aandehul.checkins.v1`)||`{}`);return Object.fromEntries(Object.entries(e).filter(([e,t])=>/^\d{4}-\d{2}-\d{2}$/.test(e)&&B.some(e=>e.id===t)))}catch{return{}}}var ye=window.chrome?.webview,K=null,be=window.matchMedia(`(display-mode: standalone)`).matches||!!navigator.standalone,xe=`Alle`,q=we(),Se=H(new Date);document.documentElement.classList.add(`js`);var J=document.querySelector(`#app`),Ce=()=>G()[H(new Date)];document.documentElement.classList.toggle(`less-motion`,ve(`aandehul.less-motion`)===`on`);function we(){let e=location.hash.slice(1);return Object.hasOwn(L,e)?e:`pusterum`}var Te=(e=``)=>`<img src="/images/pebble.png" class="${e}" alt="" draggable="false">`,Ee=()=>`<a href="#pusterum" class="brand" aria-label="Åndehul, til forsiden">${Te(`brand-mark`)}<span>Åndehul</span></a>`,De=[{clip:`greeting`,words:`Hej med dig. Skal vi tage en lille pause sammen?`},{clip:`little-stone`,words:`Psst. Selv en sten som mig kan godt lide en lille pause.`},{clip:`welcome`,words:`Lad skuldrene hvile. Vi tager det i dit tempo.`}],Oe=0,Y=null,ke;function Ae(e){return`<button type="button" data-action="greet" class="pebble-greeting ${e}-friend" aria-label="Hør en hilsen fra Pebble">
    <span class="greet-bubble">${f(`volume-2`)}<span>Hils på mig</span></span>
    <span class="friend-shadow"></span><span class="friend-body">${te(`awake`)}</span>
  </button>`}function je(e,t,n){return`<a class="nav-link" href="#${e}" data-nav="${e}">${f(n)}<span>${t}</span></a>`}J.innerHTML=`
  <a class="skip" href="#content">Gå til indhold</a>
  <header class="mobile-bar">${Ee()}<button class="circle-button" data-action="menu" aria-label="Åbn menu" aria-expanded="false" aria-controls="sidebar">${f(`menu`)}</button></header>
  <button class="shade" aria-label="Luk menu" tabindex="-1" data-action="close-menu" hidden></button>
  <aside class="sidebar" id="sidebar" aria-label="Hovedmenu">
    <div class="sidebar-brand">${Ee()}<button data-action="close-menu" aria-label="Luk menu" class="menu-close circle-button">${f(`x`)}</button></div>
    <nav class="main-nav" aria-label="Sider">${I.map(e=>je(e.id,e.label,e.icon)).join(``)}</nav>
    <div class="sidebar-foot">
      <a href="#pebble" class="friend-card" data-nav="pebble">
        <div class="pet-habitat">${Te()}</div>
        <span class="friend-title">Din skrivebordsven</span>
        <span class="friend-link">Mød Pebble ${f(`arrow-right`)}</span>
      </a>
      ${je(`indstillinger`,`Indstillinger`,`settings`)}
    </div>
  </aside>
  <main id="content" tabindex="-1">
    <div class="content-inner">
      <header class="page-header">
        <div><div class="date-line">${f(`sun`)}<span id="today"></span></div><h1 id="page-title"></h1></div>
        <button class="sound-button" data-action="sound" aria-haspopup="dialog"></button>
      </header>
      <div id="view"></div>
    </div>
  </main>
  <dialog id="utility" aria-labelledby="utility-heading"></dialog>
  <div class="announcer" aria-live="polite" role="status"></div>`;var X=J.querySelector(`#view`),Z=J.querySelector(`#utility`),Me=e=>{J.querySelector(`.announcer`).textContent=e};function Ne(e){let t=o(e.id),n=R[e.id];return`<article class="exercise-card cover-${n}">
      <button class="exercise-open" data-start="${e.id}" aria-label="Start ${e.title}, ${e.minutes} minutter">
        <span class="cover"><img src="/images/${n}.webp" alt="" loading="lazy"></span>
        <span class="card-copy">
          <span class="category">${f(z[e.category])}${e.category}</span>
          <span class="card-title">${e.title}</span>
          <span class="card-description">${e.description}</span>
          <span class="card-bottom"><span class="time">${f(`clock`)}${e.minutes} min</span><span class="small-play">${f(`play`)}</span></span>
        </span>
      </button>
      <button class="favorite ${t?`is-saved`:``}" data-favorite="${e.id}" aria-label="${t?`Fjern`:`Gem`} ${e.title} ${t?`fra`:`i`} favoritter" aria-pressed="${t}">${f(`heart`)}</button>
    </article>`}var Pe=e=>`<div class="exercise-grid">${e.map(Ne).join(``)}</div>`;function Fe(){let t=Ce(),n=B.find(e=>e.id===t)?.reply;return`<section class="hero" aria-labelledby="hero-title">
      <div class="hero-content">
        <span class="feature-label">${f(`sunrise`)}Dagens pause</span>
        <h2 id="hero-title">Et øjebliks ro.</h2>
        <p data-greeting-line>Jeg hedder Pebble. Skal vi trække vejret sammen?</p>
        <div class="hero-actions"><button class="primary" data-start="rolig-vejrtraekning">${f(`play`)}Start en pause</button><span class="time">${f(`clock`)}3 min</span></div>
      </div>${Ae(`meadow`)}
    </section>
    <section class="suggestions" aria-labelledby="suggested">
      <div class="section-title"><h2 id="suggested">Find din øvelse</h2><a href="#bibliotek" class="text-link">Se alle øvelser ${f(`arrow-right`)}</a></div>
      ${Pe(e.slice(0,3))}
    </section>
    <section class="checkin" aria-labelledby="checkin-heading">
      <div class="checkin-intro"><span class="checkin-symbol">${f(`notebook-pen`)}</span><div><h2 id="checkin-heading">Hvordan har du det?</h2><p>${n?`Pebble siger “`+n+`”`:`Tag et øjeblik og mærk efter.`}</p></div></div>
      <div class="mood-options">${B.map(e=>`<button data-mood="${e.id}" aria-pressed="${t===e.id}" class="mood">${f(e.icon)}${e.title}</button>`).join(``)}</div>
    </section>`}function Ie(){return`<p class="page-description">Vælg en øvelse, der passer til dig lige nu.</p>
    <div class="filter-bar" role="group" aria-label="Filtrér øvelser">${[`Alle`,`Vejrtrækning`,`Meditation`,`Afspænding`].map(e=>`<button data-filter="${e}" aria-pressed="${xe===e}">${e}</button>`).join(``)}</div>
    ${Pe(e.filter(e=>xe===`Alle`||e.category===xe))}`}function Le(e,t,n){return`<div class="empty-state"><span class="empty-symbol">${f(e)}</span><h2>${t}</h2><p>${n}</p><a class="primary" href="#bibliotek">Udforsk øvelser ${f(`arrow-right`)}</a></div>`}function Re(){let t=e.filter(e=>o(e.id));return t.length?`<p class="page-description">Dine gemte øvelser, samlet ét sted.</p>${Pe(t)}`:Le(`heart`,`Plads til dine favoritter`,`Tryk på hjertet ved en øvelse, du gerne vil vende tilbage til.`)}function ze(){let t=l(),n=G(),r=[...new Set([...t.map(e=>H(new Date(e.finishedAt))),...Object.keys(n)])].sort().reverse();return r.length?`<p class="page-description">Et tilbageblik på de pauser, du har givet dig selv.</p>`+r.map(r=>{let i=B.find(e=>e.id===n[r]);return`<section class="history-day"><h2>${_e(new Date(r+`T12:00:00`))}</h2>
      ${i?`<div class="history-row"><span class="row-symbol">${f(i.icon)}</span><div><strong>${i.title}</strong><small>Dagens indtjekning</small></div></div>`:``}
      ${t.filter(e=>H(new Date(e.finishedAt))===r).map(t=>{let n=e.find(e=>e.id===t.exerciseId),r=Math.floor(t.seconds/60),i=t.seconds%60,a=r?r+` min`+(i?` `+i+` sek`:``):i+` sek`;return`<div class="history-row"><span class="row-symbol">${f(z[n?.category||`Vejrtrækning`])}</span><div><strong>${n?.title||`Vejrtrækning med Pebble`}</strong><small>${a} · ${t.completed?`Gennemført`:`Afsluttet undervejs`}</small></div><time>${ge.format(new Date(t.finishedAt))}</time></div>`}).join(``)}</section>`}).join(``):Le(`history`,`Her begynder din historik`,`Dine pauser og daglige indtjekninger dukker op her.`)}function Be(){return`<section class="companion-view"><div class="companion-art">${Ae(`portrait`)}</div>
      <div><h2>Hej, jeg er Pebble.</h2><p data-greeting-line>Jeg er en lille sten med god tid. Når jeg løfter mig, trækker vi vejret ind. Når jeg synker ned, puster vi ud.</p>
      <button class="primary" data-start="rolig-vejrtraekning" data-minutes="1">${f(`wind`)}Ét minut med mig</button>
      </div></section>
      <section class="detail-block"><h2>Pebble på skrivebordet</h2><p>På Windows kan Pebble sidde oven på dine andre vinduer. Klik på stenen for en pause, eller træk den hen, hvor den skal sidde.</p>
      ${ye?`<div class="desktop-actions"><button class="secondary" data-action="show-pebble">${f(`monitor`)}Vis Pebble på skrivebordet</button><button class="secondary" data-action="start-breathing">${f(`wind`)}Træk vejret med Pebble</button></div>`:`<a class="secondary" href="/downloads/Aandehul-Windows.zip" download>${f(`download`)}Hent til Windows</a><p class="small-note">Pak ZIP-filen ud, og start Aandehul.exe. Til Windows 10 og 11 (x64) med <a href="https://dotnet.microsoft.com/download/dotnet/10.0" target="_blank" rel="noreferrer">.NET 10 Desktop Runtime</a> og Microsoft Edge WebView2.</p>`}
      </section>`}function Ve(){let e=document.documentElement.classList.contains(`less-motion`);return`<section class="settings-list">
    <div class="settings-row"><span class="row-symbol">${f(`leaf`)}</span><div><strong>Mindre bevægelse</strong><p>Gør animationerne i øvelserne mere stille.</p></div><button data-action="motion" role="switch" aria-checked="${e}" aria-label="Mindre bevægelse" class="switch"><span></span></button></div>
    <div class="settings-row"><span class="row-symbol">${f(`headphones`)}</span><div><strong>Lydmiljø</strong><p>Vælg en baggrundslyd og dens lydstyrke.</p></div><button class="secondary" data-action="sound">Vælg lyd</button></div>
    ${ye?``:`<div class="settings-row"><span class="row-symbol">${f(`download`)}</span><div><strong>Installér Åndehul</strong><p>Åbn dit pusterum som app på denne enhed.</p></div>${be?`<span class="installed">Installeret</span>`:`<button class="secondary" data-action="install">Installér</button>`}</div>`}
    <div class="settings-row"><span class="row-symbol">${f(`monitor`)}</span><div><strong>Lokalt på din enhed</strong><p>Dine favoritter, pauser og indtjekninger gemmes i denne app.</p></div></div>
  </section>`}function He(){let{selected:e}=N(),t=e!==`off`,n=J.querySelector(`.sound-button`);n.classList.toggle(`playing`,t),n.innerHTML=f(t?`audio-lines`:`volume-2`)+`<span>`+(t?D.find(t=>t.id===e).name:`Lydmiljø`)+`</span>`}function Q(){qe(),document.title=L[q]+` · Åndehul`,J.querySelector(`#page-title`).textContent=L[q],J.querySelector(`#today`).textContent=_e(new Date),J.querySelectorAll(`[data-nav]`).forEach(e=>{e.dataset.nav===q?e.setAttribute(`aria-current`,`page`):e.removeAttribute(`aria-current`)}),X.innerHTML={pusterum:Fe,bibliotek:Ie,favoritter:Re,historik:ze,pebble:Be,indstillinger:Ve}[q](),He()}function Ue(e,t){Z.innerHTML=`<div class="dialog-head"><h2 id="utility-heading">${e}</h2><button data-action="close" class="circle-button" aria-label="Luk">${f(`x`)}</button></div>${t}`,Z.open||Z.showModal()}function We(){let{selected:e,level:t}=N();Ue(`Lydmiljø`,`<p>Vælg en lyd til dit pusterum.</p><div class="sounds">${D.map(t=>`<button data-audio="${t.id}" aria-pressed="${t.id===e}">${f(t.icon)}<span>${t.name}</span>${t.id===e?f(`check`):``}</button>`).join(``)}</div>
    <label class="volume-label" for="volume">${f(`volume-2`)} Lydstyrke <output id="volume-output">${Math.round(t*100)} %</output></label><input id="volume" type="range" min="0" max="100" value="${Math.round(t*100)}">`)}function $(e){J.classList.toggle(`menu-open`,e),J.querySelector(`main`).inert=e,J.querySelector(`.mobile-bar`).inert=e,J.querySelector(`.skip`).inert=e;let t=J.querySelector(`[data-action="menu"]`);t.setAttribute(`aria-expanded`,String(e)),J.querySelector(`.shade`).hidden=!e,e?J.querySelector(`.menu-close`).focus():window.matchMedia(`(max-width: 820px)`).matches&&J.querySelector(`#sidebar`).contains(document.activeElement)&&t.focus()}function Ge(e,t){X.querySelector(`[${e}="${CSS.escape(t)}"]`)?.focus({preventScroll:!0})}function Ke(e){e.querySelector(`.pebble-figure`)?.classList.remove(`is-talking`);let t=e.querySelector(`.pebble-figure`);t.dataset.pose=`happy`,e.querySelector(`.greet-bubble span`).textContent=`Hils igen`,e.setAttribute(`aria-label`,`Hør en ny hilsen fra Pebble`),ke=window.setTimeout(()=>{t.dataset.pose=`awake`},1400)}function qe(){if(window.clearTimeout(ke),!Y)return;let e=Y;Y=null,ce(),Ke(e)}async function Je(e){if(Y){qe();return}window.clearTimeout(ke);let t=Oe++,n=De[t%De.length];Y=e,X.querySelector(`[data-greeting-line]`).textContent=n.words,e.querySelector(`.pebble-figure`).dataset.pose=`listening`,e.querySelector(`.greet-bubble span`).textContent=`Stop hilsen`,e.setAttribute(`aria-label`,`Stop Pebbles hilsen`),!await oe(n.clip)&&Y===e&&Oe===t+1&&(qe(),Me(n.words))}window.addEventListener(`aandehul:pebble-speaking`,e=>{Y&&Y.querySelector(`.pebble-figure`).classList.toggle(`is-talking`,e.detail)}),window.addEventListener(`aandehul:pebble-voice-ended`,()=>{Y&&=(Ke(Y),null)}),J.addEventListener(`click`,async e=>{let t=e.target.closest(`button,a`);if(!t)return;let{action:n,start:r,favorite:i,mood:a,filter:o,audio:c}=t.dataset;if(r)qe(),E(r,t.dataset.minutes?Number(t.dataset.minutes):void 0);else if(i){let e=[...X.querySelectorAll(`[data-favorite]`)].indexOf(t),n=s(i);if(q===`favoritter`&&!n){let t=[...X.querySelectorAll(`[data-favorite]`)];(t[Math.min(e,t.length-1)]??X.querySelector(`.empty-state a`))?.focus({preventScroll:!0})}Me(n?`Gemt i dine favoritter.`:`Fjernet fra dine favoritter.`)}else if(a&&B.some(e=>e.id===a)){let e=G();e[H(new Date)]=a,W(`aandehul.checkins.v1`,JSON.stringify(e)),Q(),Ge(`data-mood`,a),Me(`Din indtjekning er gemt.`)}else if(o)xe=o,Q(),Ge(`data-filter`,o);else if(c&&D.some(e=>e.id===c)){try{await F(c),Z.open&&(We(),Z.querySelector(`[data-audio="${c}"]`)?.focus())}catch{Ue(`Lydmiljø`,`<p>Lyden kunne ikke startes på denne enhed. Prøv igen, når din lydudgang er klar.</p>`)}He()}else if(t.classList.contains(`skip`))e.preventDefault(),J.querySelector(`#content`).focus();else switch(t.matches(`[data-nav],.brand`)&&$(!1),n){case`greet`:await Je(t);break;case`menu`:$(!0);break;case`close-menu`:$(!1);break;case`close`:Z.close();break;case`sound`:We();break;case`show-pebble`:case`start-breathing`:ye?.postMessage(n);break;case`motion`:{let e=document.documentElement.classList.toggle(`less-motion`);W(`aandehul.less-motion`,e?`on`:`off`),t.setAttribute(`aria-checked`,String(e));break}case`install`:if(K){let e=K;K=null,await e.prompt(),(await e.userChoice).outcome===`accepted`&&(be=!0,Q())}else Ue(`Installér Åndehul`,/iPad|iPhone|iPod/.test(navigator.userAgent)||navigator.platform===`MacIntel`&&navigator.maxTouchPoints>1?`<p>Åbn Åndehul i Safari. Tryk på Del og vælg Føj til hjemmeskærm. Åbn derefter Åndehul fra det nye ikon.</p>`:`<p>Åbn browserens menu og vælg Installér app eller Føj til startskærm, hvis muligheden vises. På en computer kan du åbne Åndehul i Chrome eller Edge for at installere den.</p>`)}}),Z.addEventListener(`click`,e=>{if(e.target!==Z)return;let t=Z.getBoundingClientRect();(e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom)&&Z.close()}),J.addEventListener(`input`,e=>{let t=e.target;t.id===`volume`&&(P(Number(t.value)/100),Z.querySelector(`output`).value=t.value+` %`)}),window.addEventListener(`hashchange`,()=>{q=we(),$(!1),Q(),window.scrollTo(0,0),J.querySelector(`#content`).focus({preventScroll:!0})}),window.addEventListener(`keydown`,e=>{if(J.classList.contains(`menu-open`)&&(e.key===`Escape`&&$(!1),e.key===`Tab`)){let t=[...J.querySelectorAll(`#sidebar a,#sidebar button`)].filter(e=>e.offsetParent!==null);e.shiftKey&&document.activeElement===t[0]?(e.preventDefault(),t.at(-1)?.focus()):!e.shiftKey&&document.activeElement===t.at(-1)&&(e.preventDefault(),t[0]?.focus())}}),window.matchMedia(`(max-width: 820px)`).addEventListener(`change`,()=>$(!1)),window.addEventListener(`aandehul:change`,()=>{if(q===`historik`){Q();return}let t=[...X.querySelectorAll(`[data-favorite]`)];if(q===`favoritter`&&(t.length!==e.filter(e=>o(e.id)).length||t.some(e=>!o(e.dataset.favorite))))Q();else for(let n of t){let t=e.find(e=>e.id===n.dataset.favorite);if(!t)continue;let r=o(t.id);n.classList.toggle(`is-saved`,r),n.setAttribute(`aria-pressed`,String(r)),n.setAttribute(`aria-label`,r?`Fjern `+t.title+` fra favoritter`:`Gem `+t.title+` i favoritter`)}}),window.addEventListener(`storage`,e=>{e.key===null?U.clear():U.delete(e.key),(e.key===null||e.key===`aandehul.less-motion`)&&(document.documentElement.classList.toggle(`less-motion`,ve(`aandehul.less-motion`)===`on`),q===`indstillinger`&&Q()),e.key!==null&&e.key!==`aandehul.checkins.v1`||q!==`historik`&&q!==`pusterum`||Q()}),window.addEventListener(`beforeinstallprompt`,e=>{e.preventDefault(),K=e}),window.addEventListener(`appinstalled`,()=>{be=!0,K=null,q===`indstillinger`&&Q()});function Ye(){let e=H(new Date);Se!==e&&(Se=e,Q())}window.addEventListener(`focus`,Ye),window.setInterval(Ye,6e4),Q();