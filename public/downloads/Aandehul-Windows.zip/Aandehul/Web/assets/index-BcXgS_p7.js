(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[{id:`rolig-vejrtraekning`,title:`Rolig vejrtrækning`,description:`Følg en blid rytme, ét åndedrag ad gangen.`,category:`Vejrtrækning`,minutes:3,durations:[1,3,5],breath:{inhale:4,exhale:4},steps:[{title:`Træk vejret ind`,instruction:`Lad luften komme stille ind i dit eget tempo.`},{title:`Pust langsomt ud`,instruction:`Lad skuldrene hvile, mens luften slipper ud.`}]},{id:`kropsscanning`,title:`Kropsscanning`,description:`Lad opmærksomheden gå på besøg i kroppen.`,category:`Afspænding`,minutes:5,durations:[3,5,10],steps:[{title:`Find dig til rette`,instruction:`Mærk fladen under dig. Lad hænderne hvile, hvor de har lyst.`},{title:`Mærk dine fødder`,instruction:`Læg mærke til tæerne, hælene og kontakten med gulvet.`},{title:`Giv benene plads`,instruction:`Flyt opmærksomheden langsomt fra anklerne op mod hofterne.`},{title:`Hvil i midten`,instruction:`Læg mærke til den lille bevægelse i maven, når du trækker vejret.`},{title:`Mærk dine skuldre`,instruction:`Følg armene helt ud til fingerspidserne. Måske føles én hånd varmere.`},{title:`Vend stille tilbage`,instruction:`Mærk kroppen som en helhed. Bevæg forsigtigt fingre og tæer.`}]},{id:`giv-slip-paa-dagen`,title:`Giv slip på dagen`,description:`En stille meditation til dagens sidste stund.`,category:`Meditation`,minutes:7,durations:[3,7,10],steps:[{title:`Land her`,instruction:`Lad blikket hvile på et roligt punkt, eller luk øjnene et øjeblik.`},{title:`Lad dagen passere`,instruction:`Måske dukker et øjeblik fra dagen op. Lad det ligge et øjeblik.`},{title:`Mærk et åndedrag`,instruction:`Følg luften ind og ud. Du må gerne vende tilbage til åndedrættet mange gange.`},{title:`Find én lille ting`,instruction:`Tænk på en lille ting fra i dag, som var rar. Bliv lidt ved den.`},{title:`Tag roen med`,instruction:`Mærk rummet omkring dig, og kom langsomt tilbage i dit eget tempo.`}]},{id:`et-roligt-oejeblik`,title:`Et roligt øjeblik`,description:`Find et lille holdepunkt i lydene omkring dig.`,category:`Meditation`,minutes:3,durations:[1,3,5],steps:[{title:`Sæt dig godt`,instruction:`Lad kroppen finde en rar stilling. Mærk dine fødder mod underlaget.`},{title:`Lyt til rummet`,instruction:`Læg mærke til en lyd i nærheden. Lad den komme og gå.`},{title:`Lyt lidt længere væk`,instruction:`Måske kan du høre noget udenfor. Vend roligt tilbage, når tankerne vandrer.`},{title:`Vend tilbage`,instruction:`Lad blikket glide rundt i rummet. Giv dig tid til at komme videre.`}]},{id:`blid-udanding`,title:`Blid udånding`,description:`Giv udåndingen lidt ekstra tid og plads.`,category:`Vejrtrækning`,minutes:2,durations:[1,2,5],breath:{inhale:3,exhale:5},steps:[{title:`Træk vejret ind`,instruction:`Tag en let indånding i en rytme, som passer dig.`},{title:`Lad luften slippe ud`,instruction:`Giv udåndingen lidt længere tid, så længe det føles rart.`}]},{id:`lette-skuldre`,title:`Lette skuldre`,description:`En lille afspænding ved skrivebordet.`,category:`Afspænding`,minutes:3,durations:[1,3,5],steps:[{title:`Find en rar stilling`,instruction:`Lad fødderne hvile mod gulvet og armene ligge løst langs siden.`},{title:`Mærk dine skuldre`,instruction:`Læg mærke til, hvordan skuldrene føles lige nu.`},{title:`Løft ganske let`,instruction:`Hvis det føles rart, så løft langsomt skuldrene en smule og lad dem synke igen.`},{title:`Lad armene hvile`,instruction:`Mærk vægten i hænderne. Giv kæben lidt plads.`},{title:`Find tilbage`,instruction:`Bevæg forsigtigt fingrene og lad blikket vende tilbage til rummet.`}]}],t=`aandehul.session.v1.`,n=`aandehul.favorite.v1.`,r=new Map;function i(e){if(r.has(e))return r.get(e);try{return localStorage.getItem(e)}catch{return null}}function a(e,t){let n=!0;try{localStorage.setItem(e,t),r.delete(e)}catch{r.set(e,t),n=!1}return window.dispatchEvent(new Event(`aandehul:change`)),n}typeof window<`u`&&window.addEventListener(`storage`,e=>{(e.key===null||e.key.startsWith(t)||e.key.startsWith(n))&&(e.key===null?r.clear():r.delete(e.key),window.dispatchEvent(new Event(`aandehul:change`)))});function o(e){return i(n+e)===`true`}function s(t){if(!e.some(e=>e.id===t))return!1;let r=!o(t);return a(n+t,String(r)),r}function c(t){if(!t||typeof t!=`object`)return!1;let n=t;return typeof n.exerciseId==`string`&&e.some(e=>e.id===n.exerciseId)&&typeof n.seconds==`number`&&Number.isFinite(n.seconds)&&n.seconds>0&&typeof n.startedAt==`string`&&Number.isFinite(Date.parse(n.startedAt))&&typeof n.finishedAt==`string`&&Number.isFinite(Date.parse(n.finishedAt))&&typeof n.completed==`boolean`}function l(){let e=new Set(r.keys());try{for(let n=0;n<localStorage.length;n++){let r=localStorage.key(n);r?.startsWith(t)&&e.add(r)}}catch{}let n=[];for(let r of e)if(r.startsWith(t))try{let e=JSON.parse(i(r)??`null`);c(e)&&n.push(e)}catch{}return n.sort((e,t)=>Date.parse(t.finishedAt)-Date.parse(e.finishedAt))}function u(e){if(!c(e))return!1;let n=t+e.exerciseId+`.`+e.startedAt,o=JSON.stringify(e);return!r.has(n)&&i(n)===o||a(n,o)}if(typeof window<`u`){let e=window.chrome?.webview;e&&(e.addEventListener(`message`,t=>{let n=t.data;n?.type===`pebble-session`&&c(n.record)&&u(n.record)&&e.postMessage(`pebble-saved:`+n.record.startedAt)}),e.postMessage(`pebble-ready`))}function d(e,t,n){if(e.breath){let{inhale:n,exhale:r}=e.breath,i=t%(n+r),a=i<n,o=a?n:r,s=(a?i:i-n)/o,c=(1-Math.cos(Math.PI*s))/2;return{...e.steps[+!a],index:+!a,expansion:a?c:1-c}}let r=Math.min(e.steps.length-1,Math.floor(t/n*e.steps.length));return{...e.steps[r],index:r,expansion:(1-Math.cos(t/5))/2}}var f=Object.assign({"./icons/arrow-right.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-arrow-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
  <path d="m12 5 7 7-7 7" />
</svg>
`,"./icons/audio-lines.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-audio-lines"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 10v3" />
  <path d="M6 6v11" />
  <path d="M10 3v18" />
  <path d="M14 8v7" />
  <path d="M18 5v13" />
  <path d="M22 10v3" />
</svg>
`,"./icons/book-open.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-book-open"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 5v16" />
  <path d="M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z" />
</svg>
`,"./icons/check.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 6 9 17l-5-5" />
</svg>
`,"./icons/clock.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-clock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 6v6l4 2" />
</svg>
`,"./icons/cloud-moon.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-cloud-moon"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M13 16a3 3 0 0 1 0 6H7a5 5 0 1 1 4.9-6z" />
  <path d="M18.376 14.512a6 6 0 0 0 3.461-4.127c.148-.625-.659-.97-1.248-.714a4 4 0 0 1-5.259-5.26c.255-.589-.09-1.395-.716-1.248a6 6 0 0 0-4.594 5.36" />
</svg>
`,"./icons/cloud-rain.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-cloud-rain"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242" />
  <path d="M16 14v6" />
  <path d="M8 14v6" />
  <path d="M12 16v6" />
</svg>
`,"./icons/download.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-download"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 15V3" />
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
  <path d="m7 10 5 5 5-5" />
</svg>
`,"./icons/flower-2.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-flower-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 5a3 3 0 1 1 3 3m-3-3a3 3 0 1 0-3 3m3-3v1M9 8a3 3 0 1 0 3 3M9 8h1m5 0a3 3 0 1 1-3 3m3-3h-1m-2 3v-1" />
  <circle cx="12" cy="8" r="2" />
  <path d="M12 10v12" />
  <path d="M12 22c4.2 0 7-1.667 7-5-4.2 0-7 1.667-7 5Z" />
  <path d="M12 22c-4.2 0-7-1.667-7-5 4.2 0 7 1.667 7 5Z" />
</svg>
`,"./icons/frown.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-frown"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 10V9" />
  <path d="M9 10V9" />
  <path d="M9 16a5 5 0 016 0" />
  <circle cx="12" cy="12" r="10" />
</svg>
`,"./icons/headphones.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-headphones"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3" />
</svg>
`,"./icons/heart.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-heart"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5" />
</svg>
`,"./icons/history.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-history"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
  <path d="M3 3v5h5" />
  <path d="M12 7v5l4 2" />
</svg>
`,"./icons/house.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-house"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8" />
  <path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
</svg>
`,"./icons/leaf.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-leaf"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 20a10 10 0 0010-10 25.9 25.9 0 00-1.04-7.281 1 1 0 00-1.755-.325C15.833 5.5 13 5.5 9.8 6.1A7 7 0 0011 20" />
  <path d="M2 21a5 5 0 012.911-4.544C7.613 15.212 8.351 15.24 11 13" />
</svg>
`,"./icons/menu.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-menu"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 5h16" />
  <path d="M4 12h16" />
  <path d="M4 19h16" />
</svg>
`,"./icons/monitor.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-monitor"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="14" x="2" y="3" rx="2" />
  <line x1="8" x2="16" y1="21" y2="21" />
  <line x1="12" x2="12" y1="17" y2="21" />
</svg>
`,"./icons/moon-star.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-moon-star"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 5h4" />
  <path d="M20 3v4" />
  <path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401" />
</svg>
`,"./icons/notebook-pen.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-notebook-pen"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" />
  <path d="M2 6h4" />
  <path d="M2 10h4" />
  <path d="M2 14h4" />
  <path d="M2 18h4" />
  <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" />
</svg>
`,"./icons/pause.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-pause"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect x="14" y="3" width="5" height="18" rx="1" />
  <rect x="5" y="3" width="5" height="18" rx="1" />
</svg>
`,"./icons/play.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-play"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z" />
</svg>
`,"./icons/settings.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-settings"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915" />
  <circle cx="12" cy="12" r="3" />
</svg>
`,"./icons/smile.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-smile"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 10V9" />
  <path d="M16.472 15a6 6 0 01-8.943 0" />
  <path d="M9 10V9" />
  <circle cx="12" cy="12" r="10" />
</svg>
`,"./icons/sun.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-sun"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="4" />
  <path d="M12 2v2" />
  <path d="M12 20v2" />
  <path d="m4.93 4.93 1.41 1.41" />
  <path d="m17.66 17.66 1.41 1.41" />
  <path d="M2 12h2" />
  <path d="M20 12h2" />
  <path d="m6.34 17.66-1.41 1.41" />
  <path d="m19.07 4.93-1.41 1.41" />
</svg>
`,"./icons/sunrise.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-sunrise"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 2v8" />
  <path d="m4.93 10.93 1.41 1.41" />
  <path d="M2 18h2" />
  <path d="M20 18h2" />
  <path d="m19.07 10.93-1.41 1.41" />
  <path d="M22 22H2" />
  <path d="m8 6 4-4 4 4" />
  <path d="M16 18a4 4 0 0 0-8 0" />
</svg>
`,"./icons/volume-2.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-volume-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z" />
  <path d="M16 9a5 5 0 0 1 0 6" />
  <path d="M19.364 18.364a9 9 0 0 0 0-12.728" />
</svg>
`,"./icons/volume-x.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-volume-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 4.702a.7.7 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.7.7 0 0 0 11 19.298z" />
  <path d="m16.5 14.5 5-5" />
  <path d="m16.5 9.5 5 5" />
</svg>
`,"./icons/waves.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-waves"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2 12q2.5 2 5 0t5 0 5 0 5 0" />
  <path d="M2 19q2.5 2 5 0t5 0 5 0 5 0" />
  <path d="M2 5q2.5 2 5 0t5 0 5 0 5 0" />
</svg>
`,"./icons/wind.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-wind"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.8 19.6A2 2 0 1 0 14 16H2" />
  <path d="M17.5 8a2.5 2.5 0 1 1 2 4H2" />
  <path d="M9.8 4.4A2 2 0 1 1 11 8H2" />
</svg>
`,"./icons/x.svg":`<!-- @license lucide-static v1.79.0 - ISC -->
<svg
  class="lucide lucide-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 6 6 18" />
  <path d="m6 6 12 12" />
</svg>
`});function p(e){let t=f[`./icons/`+e+`.svg`];return t?t.replace(`<svg`,`<svg aria-hidden="true" focusable="false"`):``}var ee=`aandehul.cue-sound.v1`,te=`aandehul.cue-speech.v1`,m=null;function h(e){return Math.floor(e/60)+`:`+String(e%60).padStart(2,`0`)}function ne(e){try{return localStorage.getItem(e)===`on`}catch{return!1}}function re(e,t){try{localStorage.setItem(e,t?`on`:`off`)}catch{}}function ie(e,t){if(e.state!==`running`)return;let n=e.currentTime;for(let[r,i,a]of[[1,.065,1.65],[2,.012,.9]]){let o=e.createOscillator(),s=e.createGain();o.type=`sine`,o.frequency.value=t*r,s.gain.setValueAtTime(1e-4,n),s.gain.exponentialRampToValueAtTime(i,n+.055),s.gain.exponentialRampToValueAtTime(1e-4,n+a),o.connect(s).connect(e.destination),o.start(n),o.stop(n+a+.02),o.onended=()=>{o.disconnect(),s.disconnect()}}}function g(t){let n=e.find(e=>e.id===t);if(!n)return;if(m){m.focus();return}let r=document.createElement(`dialog`);m=r,r.className=`coach-player`,r.setAttribute(`aria-labelledby`,`coach-exercise-title`),r.innerHTML=`
    <div class="coach-sheet">
      <div class="coach-topline">
        <span class="coach-category"></span>
        <button type="button" class="coach-close" aria-label="Afslut og luk øvelsen" title="Afslut og luk">${p(`x`)}</button>
      </div>
      <h2 id="coach-exercise-title"></h2>
      <div class="coach-orbit" aria-hidden="true">
        <div class="coach-orbit-rings"></div>
        <img class="coach-pebble" src="./images/pebble.png" alt="" />
      </div>
      <div class="coach-cue" aria-live="polite" aria-atomic="true">
        <h3></h3><p></p>
      </div>
      <div class="coach-session-controls">
        <div class="coach-time">
          <span class="coach-timer" role="timer" aria-label="Tid brugt">0:00</span>
          <progress class="coach-progress" aria-label="Forløbet tid"></progress>
          <span class="coach-total"></span>
        </div>
        <div class="coach-actions">
          <label class="coach-duration">Varighed
            <select aria-label="Varighed i minutter"></select>
          </label>
          <button type="button" class="coach-playback"></button>
          <button type="button" class="coach-sound" aria-pressed="false"></button>
        </div>
        <button type="button" class="coach-speech" aria-pressed="false" hidden>${p(`book-open`)} Læs trin op</button>
      </div>
      <button type="button" class="coach-done" hidden>Tilbage til mit åndehul</button>
    </div>`;let i=e=>r.querySelector(e),a=i(`.coach-orbit`),o=i(`.coach-cue h3`),s=i(`.coach-cue p`),c=i(`.coach-session-controls`),l=i(`.coach-playback`),f=i(`.coach-close`),g=i(`.coach-done`),_=i(`.coach-sound`),v=i(`.coach-speech`),y=i(`select`),b=i(`.coach-timer`),x=i(`.coach-total`),S=i(`.coach-progress`);i(`.coach-category`).textContent=n.category,i(`#coach-exercise-title`).textContent=n.title,y.replaceChildren(...n.durations.map(e=>new Option(e+` min`,String(e)))),y.value=String(n.minutes);let C=new Date().toISOString(),w=n.minutes*60,T=0,E=performance.now(),D=-1,O=-1,k=ne(ee)&&typeof AudioContext<`u`,A,j=window.speechSynthesis,M,N=null,P=ne(te),F=!1,I=!1,L=0;function R(){let e=E===null?0:(performance.now()-E)/1e3;return Math.min(w,T+e)}async function z(e){if(k&&typeof AudioContext<`u`)try{A??=new AudioContext,A.state===`suspended`&&await A.resume(),!I&&k&&(E!==null||F)&&ie(A,e)}catch{I||(k=!1,B())}}function B(){_.innerHTML=p(k?`volume-2`:`volume-x`)+`<span>Klange</span>`,_.setAttribute(`aria-pressed`,String(k)),_.title=k?`Slå guideklange fra`:`Slå guideklange til`,_.setAttribute(`aria-label`,_.title),_.disabled=typeof AudioContext>`u`}function V(){N&&(N=null,j.cancel())}function H(){if(V(),!M||!P||F||I||E===null||D<0)return;let e=n.steps[D],t=n.breath?e.title:e.title+`. `+e.instruction,r=new SpeechSynthesisUtterance(t);N=r,r.voice=M,r.lang=M.lang,r.rate=.94,r.onend=()=>{N===r&&(N=null)},r.onerror=e=>{N===r&&(N=null,e.error!==`canceled`&&e.error!==`interrupted`&&(P=!1,v.setAttribute(`aria-pressed`,`false`),v.title=`Stemmen kunne ikke starte. Prøv igen.`))},j.speak(r)}function U(){let e=M?.voiceURI;M=j?.getVoices().find(e=>e.localService&&/^da(?:[-_]|$)/i.test(e.lang)),v.hidden=!M,v.setAttribute(`aria-pressed`,String(P&&!!M)),e!==M?.voiceURI&&H()}function W(){let e=E===null;l.innerHTML=p(e?`play`:`pause`)+(e?`Fortsæt`:`Pause`),l.setAttribute(`aria-label`,e?`Fortsæt øvelsen`:`Sæt øvelsen på pause`),r.classList.toggle(`coach-paused`,e)}function G(e,n){let r=Math.floor(n);r>0&&u({exerciseId:t,startedAt:C,finishedAt:new Date().toISOString(),seconds:r,completed:e})}function ae(){F||I||(F=!0,E=null,T=w,window.clearInterval(L),G(!0,w),V(),z(523.25),a.style.setProperty(`--coach-expansion`,`0.5`),o.textContent=`Din øvelse er færdig`,s.textContent=`Tag et øjeblik, før du går videre. Tak for pausen.`,c.hidden=!0,g.hidden=!1,f.setAttribute(`aria-label`,`Luk afspilleren`),f.title=`Luk`,g.focus({preventScroll:!0}))}function K(){if(I||F)return;let e=R();if(e>=w){ae();return}let t=Math.floor(e);if(t!==O&&(O=t,b.textContent=h(t)),S.value=e,E===null)return;let r=d(n,e,w);a.style.setProperty(`--coach-expansion`,r.expansion.toFixed(4)),r.index!==D&&(D=r.index,o.textContent=r.title,s.textContent=r.instruction,H(),z(r.index%2==0?392:329.63))}function q(){if(I)return;I=!0;let e=R();window.clearInterval(L),window.removeEventListener(`pagehide`,q),document.removeEventListener(`visibilitychange`,K),j?.removeEventListener(`voiceschanged`,U),V(),A&&A.close().catch(()=>{}),r.open&&r.close(),r.remove(),m=null,F||G(e>=w,e)}l.addEventListener(`click`,()=>{E===null?(E=performance.now(),D=-1):(T=R(),E=null,V(),A?.state===`running`&&A.suspend().catch(()=>{}),o.textContent=`På pause`,s.textContent=`Fortsæt, når du har lyst.`),W(),K()}),_.addEventListener(`click`,()=>{k=!k,re(ee,k),B(),k?z(392):A?.state===`running`&&A.suspend().catch(()=>{})}),v.addEventListener(`click`,()=>{P=!P,re(te,P),v.setAttribute(`aria-pressed`,String(P)),v.removeAttribute(`title`),H()}),y.addEventListener(`change`,()=>{w=Number(y.value)*60,S.max=w,x.textContent=h(w),K()}),f.addEventListener(`click`,q),g.addEventListener(`click`,q),r.addEventListener(`cancel`,e=>{e.preventDefault(),q()}),r.addEventListener(`close`,q),r.addEventListener(`click`,e=>{if(e.target!==r)return;let t=r.getBoundingClientRect();(e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom)&&q()}),window.addEventListener(`pagehide`,q,{once:!0}),document.addEventListener(`visibilitychange`,K),j?.addEventListener(`voiceschanged`,U),U(),S.max=w,x.textContent=h(w),W(),B(),document.body.appendChild(r),r.showModal(),l.focus({preventScroll:!0}),K(),L=window.setInterval(K,120)}var _=[{id:`off`,name:`Stilhed`,icon:`volume-x`},{id:`rain`,name:`Stille regn`,icon:`cloud-rain`},{id:`sea`,name:`Havbrus`,icon:`waves`},{id:`wind`,name:`Skovvind`,icon:`wind`}],v=`off`,y=null,b=null,x=0,S=.35;try{let e=localStorage.getItem(`aandehul.ambient.volume`);e!==null&&Number.isFinite(Number(e))&&(S=Math.max(0,Math.min(1,Number(e))))}catch{}var C=()=>({selected:v,level:S});function w(e){S=Math.max(0,Math.min(1,e)),y&&b&&b.gain.setTargetAtTime(S*.48,y.currentTime,.12);try{localStorage.setItem(`aandehul.ambient.volume`,String(S))}catch{}}async function T(e){let t=++x,n=y;if(n&&b&&(b.gain.setTargetAtTime(0,n.currentTime,.045),window.setTimeout(()=>{n.close().catch(()=>{})},200)),y=null,b=null,v=`off`,e===`off`)return;let r=new AudioContext;try{if(await r.resume(),t!==x){await r.close();return}let n=r.createBuffer(1,r.sampleRate*5,r.sampleRate),i=n.getChannelData(0),a=0;for(let t=0;t<i.length;t++){let n=Math.random()*2-1;a=(a+n*.035)/1.035,i[t]=e===`rain`?n*.55+a:a*4}let o=r.createBufferSource();o.buffer=n,o.loop=!0;let s=r.createBiquadFilter();s.type=`lowpass`,s.Q.value=.45,s.frequency.value=e===`rain`?2350:e===`sea`?1150:720;let c=r.createGain();c.gain.value=e===`rain`?.75:.6;let l=r.createOscillator(),u=r.createGain();u.gain.value=e===`rain`?.07:e===`sea`?.38:.21,l.frequency.value=e===`sea`?.093:.062,l.connect(u).connect(c.gain);let d=r.createGain();d.gain.value=0,o.connect(s).connect(c).connect(d).connect(r.destination),y=r,b=d,v=e,l.start(),o.start(),d.gain.setTargetAtTime(S*.48,r.currentTime,.4)}catch(e){throw r.state!==`closed`&&r.close().catch(()=>{}),e}}var E=[{id:`pusterum`,label:`Mit pusterum`,icon:`house`},{id:`bibliotek`,label:`Øvelsesbibliotek`,icon:`book-open`},{id:`favoritter`,label:`Mine favoritter`,icon:`heart`},{id:`historik`,label:`Min historik`,icon:`history`}],D={pusterum:`Mit pusterum`,bibliotek:`Øvelsesbibliotek`,favoritter:`Mine favoritter`,historik:`Min historik`,pebble:`Min skrivebordsven`,indstillinger:`Indstillinger`},O={"rolig-vejrtraekning":`breath`,kropsscanning:`body`,"giv-slip-paa-dagen":`evening`,"et-roligt-oejeblik":`pond`,"blid-udanding":`reeds`,"lette-skuldre":`hills`},k={Vejrtrækning:`wind`,Afspænding:`flower-2`,Meditation:`moon-star`},A=[{id:`urolig`,title:`Urolig`,icon:`frown`},{id:`traet`,title:`Træt`,icon:`cloud-moon`},{id:`tilpas`,title:`Tilpas`,icon:`smile`},{id:`glad`,title:`Glad`,icon:`sun`}],j=new Intl.DateTimeFormat(`da-DK`,{weekday:`long`,day:`numeric`,month:`long`}),M=new Intl.DateTimeFormat(`da-DK`,{hour:`2-digit`,minute:`2-digit`});function N(e){let t=j.format(e);return t.charAt(0).toUpperCase()+t.slice(1)}var P=e=>[e.getFullYear(),String(e.getMonth()+1).padStart(2,`0`),String(e.getDate()).padStart(2,`0`)].join(`-`),F=new Map;function I(e){if(F.has(e))return F.get(e);try{return localStorage.getItem(e)}catch{return null}}function L(e,t){try{localStorage.setItem(e,t),F.delete(e)}catch{F.set(e,t)}}function R(){try{let e=JSON.parse(I(`aandehul.checkins.v1`)||`{}`);return Object.fromEntries(Object.entries(e).filter(([e,t])=>/^\d{4}-\d{2}-\d{2}$/.test(e)&&A.some(e=>e.id===t)))}catch{return{}}}var z=window.chrome?.webview,B=null,V=window.matchMedia(`(display-mode: standalone)`).matches||!!navigator.standalone,H=`Alle`,U=K(),W=P(new Date);document.documentElement.classList.add(`js`);var G=document.querySelector(`#app`),ae=()=>R()[P(new Date)];document.documentElement.classList.toggle(`less-motion`,I(`aandehul.less-motion`)===`on`);function K(){let e=location.hash.slice(1);return Object.hasOwn(D,e)?e:`pusterum`}var q=(e=``)=>`<img src="/images/pebble.png" class="${e}" alt="" draggable="false">`,oe=()=>`<a href="#pusterum" class="brand" aria-label="Åndehul, til forsiden">${q(`brand-mark`)}<span>Åndehul</span></a>`;function se(e,t,n){return`<a class="nav-link" href="#${e}" data-nav="${e}">${p(n)}<span>${t}</span></a>`}G.innerHTML=`
  <a class="skip" href="#content">Gå til indhold</a>
  <header class="mobile-bar">${oe()}<button class="circle-button" data-action="menu" aria-label="Åbn menu" aria-expanded="false" aria-controls="sidebar">${p(`menu`)}</button></header>
  <button class="shade" aria-label="Luk menu" tabindex="-1" data-action="close-menu" hidden></button>
  <aside class="sidebar" id="sidebar" aria-label="Hovedmenu">
    <div class="sidebar-brand">${oe()}<button data-action="close-menu" aria-label="Luk menu" class="menu-close circle-button">${p(`x`)}</button></div>
    <nav class="main-nav" aria-label="Sider">${E.map(e=>se(e.id,e.label,e.icon)).join(``)}</nav>
    <div class="sidebar-foot">
      <a href="#pebble" class="friend-card" data-nav="pebble">
        <div class="pet-habitat">${q()}</div>
        <span class="friend-title">Din skrivebordsven</span>
        <span class="friend-link">Mød Pebble ${p(`arrow-right`)}</span>
      </a>
      ${se(`indstillinger`,`Indstillinger`,`settings`)}
    </div>
  </aside>
  <main id="content" tabindex="-1">
    <div class="content-inner">
      <header class="page-header">
        <div><div class="date-line">${p(`sun`)}<span id="today"></span></div><h1 id="page-title"></h1></div>
        <button class="sound-button" data-action="sound" aria-haspopup="dialog"></button>
      </header>
      <div id="view"></div>
    </div>
  </main>
  <dialog id="utility" aria-labelledby="utility-heading"></dialog>
  <div class="announcer" aria-live="polite" role="status"></div>`;var J=G.querySelector(`#view`),Y=G.querySelector(`#utility`),ce=e=>{G.querySelector(`.announcer`).textContent=e};function le(e){let t=o(e.id),n=O[e.id];return`<article class="exercise-card cover-${n}">
      <button class="exercise-open" data-start="${e.id}" aria-label="Start ${e.title}, ${e.minutes} minutter">
        <span class="cover"><img src="/images/${n}.webp" alt="" loading="lazy"></span>
        <span class="card-copy">
          <span class="category">${p(k[e.category])}${e.category}</span>
          <span class="card-title">${e.title}</span>
          <span class="card-description">${e.description}</span>
          <span class="card-bottom"><span class="time">${p(`clock`)}${e.minutes} min</span><span class="small-play">${p(`play`)}</span></span>
        </span>
      </button>
      <button class="favorite ${t?`is-saved`:``}" data-favorite="${e.id}" aria-label="${t?`Fjern`:`Gem`} ${e.title} ${t?`fra`:`i`} favoritter" aria-pressed="${t}">${p(`heart`)}</button>
    </article>`}var X=e=>`<div class="exercise-grid">${e.map(le).join(``)}</div>`;function ue(){let t=ae();return`<section class="hero" aria-labelledby="hero-title">
      <div class="hero-content">
        <span class="feature-label">${p(`sunrise`)}Dagens pause</span>
        <h2 id="hero-title">Et øjebliks ro.</h2>
        <p>Sænk skuldrene, og find tilbage til dit åndedræt.</p>
        <div class="hero-actions"><button class="primary" data-start="rolig-vejrtraekning">${p(`play`)}Start en pause</button><span class="time">${p(`clock`)}3 min</span></div>
      </div>
    </section>
    <section class="suggestions" aria-labelledby="suggested">
      <div class="section-title"><h2 id="suggested">Find din øvelse</h2><a href="#bibliotek" class="text-link">Se alle øvelser ${p(`arrow-right`)}</a></div>
      ${X(e.slice(0,3))}
    </section>
    <section class="checkin" aria-labelledby="checkin-heading">
      <div class="checkin-intro"><span class="checkin-symbol">${p(`notebook-pen`)}</span><div><h2 id="checkin-heading">Hvordan har du det?</h2><p>${t?`Dit svar for i dag er gemt på din enhed.`:`Tag et øjeblik og mærk efter.`}</p></div></div>
      <div class="mood-options">${A.map(e=>`<button data-mood="${e.id}" aria-pressed="${t===e.id}" class="mood">${p(e.icon)}${e.title}</button>`).join(``)}</div>
    </section>`}function de(){return`<p class="page-description">Vælg en øvelse, der passer til dig lige nu.</p>
    <div class="filter-bar" role="group" aria-label="Filtrér øvelser">${[`Alle`,`Vejrtrækning`,`Meditation`,`Afspænding`].map(e=>`<button data-filter="${e}" aria-pressed="${H===e}">${e}</button>`).join(``)}</div>
    ${X(e.filter(e=>H===`Alle`||e.category===H))}`}function fe(e,t,n){return`<div class="empty-state"><span class="empty-symbol">${p(e)}</span><h2>${t}</h2><p>${n}</p><a class="primary" href="#bibliotek">Udforsk øvelser ${p(`arrow-right`)}</a></div>`}function pe(){let t=e.filter(e=>o(e.id));return t.length?`<p class="page-description">Dine gemte øvelser, samlet ét sted.</p>${X(t)}`:fe(`heart`,`Plads til dine favoritter`,`Tryk på hjertet ved en øvelse, du gerne vil vende tilbage til.`)}function me(){let t=l(),n=R(),r=[...new Set([...t.map(e=>P(new Date(e.finishedAt))),...Object.keys(n)])].sort().reverse();return r.length?`<p class="page-description">Et tilbageblik på de pauser, du har givet dig selv.</p>`+r.map(r=>{let i=A.find(e=>e.id===n[r]);return`<section class="history-day"><h2>${N(new Date(r+`T12:00:00`))}</h2>
      ${i?`<div class="history-row"><span class="row-symbol">${p(i.icon)}</span><div><strong>${i.title}</strong><small>Dagens indtjekning</small></div></div>`:``}
      ${t.filter(e=>P(new Date(e.finishedAt))===r).map(t=>{let n=e.find(e=>e.id===t.exerciseId),r=Math.floor(t.seconds/60),i=t.seconds%60,a=r?r+` min`+(i?` `+i+` sek`:``):i+` sek`;return`<div class="history-row"><span class="row-symbol">${p(k[n?.category||`Vejrtrækning`])}</span><div><strong>${n?.title||`Vejrtrækning med Pebble`}</strong><small>${a} · ${t.completed?`Gennemført`:`Afsluttet undervejs`}</small></div><time>${M.format(new Date(t.finishedAt))}</time></div>`}).join(``)}</section>`}).join(``):fe(`history`,`Her begynder din historik`,`Dine pauser og daglige indtjekninger dukker op her.`)}function he(){return`<section class="companion-view"><div class="companion-art">${q()}</div>
      <div><h2>Mød Pebble</h2><p>Pebble er en lille sten med god tid. På Windows kan den sidde oven på dine andre vinduer og trække vejret sammen med dig.</p>
      ${z?`<button class="primary" data-action="show-pebble">${p(`monitor`)}Vis Pebble på skrivebordet</button>`:`<a class="primary" href="/downloads/Aandehul-Windows.zip" download>${p(`download`)}Hent til Windows</a>`}
      </div></section>
      <section class="detail-block"><h2>Et minut med Pebble</h2><p>Klik på stenen på skrivebordet for at starte en vejrtrækningspause. Træk den hen, hvor den skal sidde. Højreklik for at åbne menuen.</p>
      ${z?`<button class="secondary" data-action="start-breathing">${p(`wind`)}Træk vejret med Pebble</button>`:`<p class="small-note">Pak ZIP-filen ud, og start Aandehul.exe. Til Windows 10 og 11 (x64) med <a href="https://dotnet.microsoft.com/download/dotnet/10.0" target="_blank" rel="noreferrer">.NET 10 Desktop Runtime</a> og Microsoft Edge WebView2.</p>`}
      </section>`}function ge(){let e=document.documentElement.classList.contains(`less-motion`);return`<section class="settings-list">
    <div class="settings-row"><span class="row-symbol">${p(`leaf`)}</span><div><strong>Mindre bevægelse</strong><p>Gør animationerne i øvelserne mere stille.</p></div><button data-action="motion" role="switch" aria-checked="${e}" aria-label="Mindre bevægelse" class="switch"><span></span></button></div>
    <div class="settings-row"><span class="row-symbol">${p(`headphones`)}</span><div><strong>Lydmiljø</strong><p>Vælg en baggrundslyd og dens lydstyrke.</p></div><button class="secondary" data-action="sound">Vælg lyd</button></div>
    ${z?``:`<div class="settings-row"><span class="row-symbol">${p(`download`)}</span><div><strong>Installér Åndehul</strong><p>Åbn dit pusterum som app på denne enhed.</p></div>${V?`<span class="installed">Installeret</span>`:`<button class="secondary" data-action="install">Installér</button>`}</div>`}
    <div class="settings-row"><span class="row-symbol">${p(`monitor`)}</span><div><strong>Lokalt på din enhed</strong><p>Dine favoritter, pauser og indtjekninger gemmes i denne app.</p></div></div>
  </section>`}function _e(){let{selected:e}=C(),t=e!==`off`,n=G.querySelector(`.sound-button`);n.classList.toggle(`playing`,t),n.innerHTML=p(t?`audio-lines`:`volume-2`)+`<span>`+(t?_.find(t=>t.id===e).name:`Lydmiljø`)+`</span>`}function Z(){document.title=D[U]+` · Åndehul`,G.querySelector(`#page-title`).textContent=D[U],G.querySelector(`#today`).textContent=N(new Date),G.querySelectorAll(`[data-nav]`).forEach(e=>{e.dataset.nav===U?e.setAttribute(`aria-current`,`page`):e.removeAttribute(`aria-current`)}),J.innerHTML={pusterum:ue,bibliotek:de,favoritter:pe,historik:me,pebble:he,indstillinger:ge}[U](),_e()}function Q(e,t){Y.innerHTML=`<div class="dialog-head"><h2 id="utility-heading">${e}</h2><button data-action="close" class="circle-button" aria-label="Luk">${p(`x`)}</button></div>${t}`,Y.open||Y.showModal()}function ve(){let{selected:e,level:t}=C();Q(`Lydmiljø`,`<p>Vælg en lyd til dit pusterum.</p><div class="sounds">${_.map(t=>`<button data-audio="${t.id}" aria-pressed="${t.id===e}">${p(t.icon)}<span>${t.name}</span>${t.id===e?p(`check`):``}</button>`).join(``)}</div>
    <label class="volume-label" for="volume">${p(`volume-2`)} Lydstyrke <output id="volume-output">${Math.round(t*100)} %</output></label><input id="volume" type="range" min="0" max="100" value="${Math.round(t*100)}">`)}function $(e){G.classList.toggle(`menu-open`,e),G.querySelector(`main`).inert=e,G.querySelector(`.mobile-bar`).inert=e,G.querySelector(`.skip`).inert=e;let t=G.querySelector(`[data-action="menu"]`);t.setAttribute(`aria-expanded`,String(e)),G.querySelector(`.shade`).hidden=!e,e?G.querySelector(`.menu-close`).focus():window.matchMedia(`(max-width: 820px)`).matches&&G.querySelector(`#sidebar`).contains(document.activeElement)&&t.focus()}function ye(e,t){J.querySelector(`[${e}="${CSS.escape(t)}"]`)?.focus({preventScroll:!0})}G.addEventListener(`click`,async e=>{let t=e.target.closest(`button,a`);if(!t)return;let{action:n,start:r,favorite:i,mood:a,filter:o,audio:c}=t.dataset;if(r)g(r);else if(i){let e=[...J.querySelectorAll(`[data-favorite]`)].indexOf(t),n=s(i);if(U===`favoritter`&&!n){let t=[...J.querySelectorAll(`[data-favorite]`)];(t[Math.min(e,t.length-1)]??J.querySelector(`.empty-state a`))?.focus({preventScroll:!0})}ce(n?`Gemt i dine favoritter.`:`Fjernet fra dine favoritter.`)}else if(a&&A.some(e=>e.id===a)){let e=R();e[P(new Date)]=a,L(`aandehul.checkins.v1`,JSON.stringify(e)),Z(),ye(`data-mood`,a),ce(`Din indtjekning er gemt.`)}else if(o)H=o,Z(),ye(`data-filter`,o);else if(c&&_.some(e=>e.id===c)){try{await T(c),Y.open&&(ve(),Y.querySelector(`[data-audio="${c}"]`)?.focus())}catch{Q(`Lydmiljø`,`<p>Lyden kunne ikke startes på denne enhed. Prøv igen, når din lydudgang er klar.</p>`)}_e()}else if(t.classList.contains(`skip`))e.preventDefault(),G.querySelector(`#content`).focus();else switch(t.matches(`[data-nav],.brand`)&&$(!1),n){case`menu`:$(!0);break;case`close-menu`:$(!1);break;case`close`:Y.close();break;case`sound`:ve();break;case`show-pebble`:case`start-breathing`:z?.postMessage(n);break;case`motion`:{let e=document.documentElement.classList.toggle(`less-motion`);L(`aandehul.less-motion`,e?`on`:`off`),t.setAttribute(`aria-checked`,String(e));break}case`install`:if(B){let e=B;B=null,await e.prompt(),(await e.userChoice).outcome===`accepted`&&(V=!0,Z())}else Q(`Installér Åndehul`,/iPad|iPhone|iPod/.test(navigator.userAgent)||navigator.platform===`MacIntel`&&navigator.maxTouchPoints>1?`<p>Åbn Åndehul i Safari. Tryk på Del og vælg Føj til hjemmeskærm. Åbn derefter Åndehul fra det nye ikon.</p>`:`<p>Åbn browserens menu og vælg Installér app eller Føj til startskærm, hvis muligheden vises. På en computer kan du åbne Åndehul i Chrome eller Edge for at installere den.</p>`)}}),Y.addEventListener(`click`,e=>{if(e.target!==Y)return;let t=Y.getBoundingClientRect();(e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom)&&Y.close()}),G.addEventListener(`input`,e=>{let t=e.target;t.id===`volume`&&(w(Number(t.value)/100),Y.querySelector(`output`).value=t.value+` %`)}),window.addEventListener(`hashchange`,()=>{U=K(),$(!1),Z(),window.scrollTo(0,0),G.querySelector(`#content`).focus({preventScroll:!0})}),window.addEventListener(`keydown`,e=>{if(G.classList.contains(`menu-open`)&&(e.key===`Escape`&&$(!1),e.key===`Tab`)){let t=[...G.querySelectorAll(`#sidebar a,#sidebar button`)].filter(e=>e.offsetParent!==null);e.shiftKey&&document.activeElement===t[0]?(e.preventDefault(),t.at(-1)?.focus()):!e.shiftKey&&document.activeElement===t.at(-1)&&(e.preventDefault(),t[0]?.focus())}}),window.matchMedia(`(max-width: 820px)`).addEventListener(`change`,()=>$(!1)),window.addEventListener(`aandehul:change`,()=>{if(U===`historik`){Z();return}let t=[...J.querySelectorAll(`[data-favorite]`)];if(U===`favoritter`&&(t.length!==e.filter(e=>o(e.id)).length||t.some(e=>!o(e.dataset.favorite))))Z();else for(let n of t){let t=e.find(e=>e.id===n.dataset.favorite);if(!t)continue;let r=o(t.id);n.classList.toggle(`is-saved`,r),n.setAttribute(`aria-pressed`,String(r)),n.setAttribute(`aria-label`,r?`Fjern `+t.title+` fra favoritter`:`Gem `+t.title+` i favoritter`)}}),window.addEventListener(`storage`,e=>{e.key===null?F.clear():F.delete(e.key),(e.key===null||e.key===`aandehul.less-motion`)&&(document.documentElement.classList.toggle(`less-motion`,I(`aandehul.less-motion`)===`on`),U===`indstillinger`&&Z()),e.key!==null&&e.key!==`aandehul.checkins.v1`||U!==`historik`&&U!==`pusterum`||Z()}),window.addEventListener(`beforeinstallprompt`,e=>{e.preventDefault(),B=e}),window.addEventListener(`appinstalled`,()=>{V=!0,B=null,U===`indstillinger`&&Z()});function be(){let e=P(new Date);W!==e&&(W=e,Z())}window.addEventListener(`focus`,be),window.setInterval(be,6e4),Z();